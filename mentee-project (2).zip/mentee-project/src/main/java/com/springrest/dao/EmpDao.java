package com.springrest.dao;

import java.util.List;

import com.springrest.model.Emp;
import com.springrest.model.Message;

public interface EmpDao {

	List<Emp> getAllEmployees();

	Emp getEmployeeById(int id);

	int save(Emp emp);

	int delete(int id);

	int update(int id, Emp emp);

	Message getMessageById(int id);

	int updateMsg(int id, Message msg);

	Message getManagerMessageById(int id);

	int updateMsgToManager(int id, Message msg);

}
