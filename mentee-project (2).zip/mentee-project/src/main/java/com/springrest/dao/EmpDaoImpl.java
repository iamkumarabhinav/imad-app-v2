package com.springrest.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;

import com.springrest.model.Emp;
import com.springrest.model.Message;
import com.springrest.util.EmpRowMapper;
import com.springrest.util.ReceivedMessageRowMapper;
import com.springrest.util.SentMessageRowMapper;

public class EmpDaoImpl implements EmpDao {
	
	@Autowired
	private JdbcTemplate template;

	
	public EmpDaoImpl() {
		super();
	}

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	public int save(Emp e){
		String query1="INSERT INTO user280 VALUES ("+e.getId()+",'letmein','employee')";
		template.update(query1);
		String query2="INSERT INTO message280 VALUES ("+e.getId()+",'','')";
		template.update(query2);
		String query="INSERT INTO employee280 VALUES ("+e.getId()+",'"+e.getName()+"','"+e.getEmail()+"','"+e.getAadhar()+"','"+e.getMobile()+"','"+e.getDrivinglicense()+"','"+e.getPan()+"',"+e.getSalary()+",'"+e.getDesignation()+"')";
		System.out.println(query);
	    return template.update(query);
	}
	
	public int update(int searchById, Emp newEmp){
		String query="UPDATE employee280 SET FullName='"+newEmp.getName()+"', Email='"+newEmp.getEmail()+"', Aadhar='"+newEmp.getAadhar()+"', mobile='"+newEmp.getMobile()+"', Drlicense='"+newEmp.getDrivinglicense()+"', pan='"+newEmp.getPan()+"', SALARY="+newEmp.getSalary()+", DESIGNATION='"+newEmp.getDesignation()+"' where userId="+newEmp.getId();
		System.out.println(query);		
		return template.update(query);
	}
	
	public int delete(int searchById){
		String query="DELETE FROM user280 WHERE userId=" + searchById;
		System.out.println(query);
		return template.update(query);
	}
	
	public Emp getEmployeeById(int searchById){
		Emp foundEmployee=null;
		String query="SELECT * FROM employee280 WHERE userId=" + searchById;
		System.out.println(query);
		foundEmployee=template.queryForObject(query,new EmpRowMapper());
		return foundEmployee;
	}
	
	@Override
	public List<Emp> getAllEmployees(){
		List<Emp> allEmployees=null;
		String query="SELECT * FROM employee280";
		System.out.println(query);
		allEmployees=template.query(query,new EmpRowMapper());
		return allEmployees;
	}

	@Override
	public Message getMessageById(int id) {
		Message foundMessage=null;
		String query="SELECT * FROM message280 WHERE userId=" + id;
		System.out.println(query);
		foundMessage=template.queryForObject(query,new ReceivedMessageRowMapper());
		return foundMessage;
	}

	@Override
	public int updateMsg(int id, Message msg) {
		// TODO Auto-generated method stub
		String query="UPDATE message280 SET sentmsg='"+msg.getMsg()+"' where userId="+msg.getEmpId();
		System.out.println(query);		
		return template.update(query);
	}

	@Override
	public Message getManagerMessageById(int id) {
		// TODO Auto-generated method stub
		Message foundMessage=null;
		String query="SELECT * FROM message280 WHERE userId=" + id;
		System.out.println(query);
		foundMessage=template.queryForObject(query,new SentMessageRowMapper());
		return foundMessage;
	}

	@Override
	public int updateMsgToManager(int id, Message msg) {
		// TODO Auto-generated method stub
		String query="UPDATE message280 SET receivedmsg='"+msg.getMsg()+"' where userId="+msg.getEmpId();
		System.out.println(query);		
		return template.update(query);
	}
	
	
}
