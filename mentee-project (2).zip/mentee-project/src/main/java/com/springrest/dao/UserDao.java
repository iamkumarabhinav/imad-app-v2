package com.springrest.dao;

public interface UserDao {

}
