package com.springrest.dao;

public class UserDaoImpl implements UserDao {

}
