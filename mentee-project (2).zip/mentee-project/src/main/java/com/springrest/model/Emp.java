package com.springrest.model;

public class Emp {

		private int id;
		private String name;
		private String email;
		private int salary;
		private String designation;
		private String aadhar;
		private String mobile;
		private String drivinglicense;
		private String pan;
		@Override
		public String toString() {
			return "Emp [id=" + id + ", name=" + name + ", email=" + email + ", salary=" + salary + ", designation="
					+ designation + ", aadhar=" + aadhar + ", mobile=" + mobile + ", drivinglicense=" + drivinglicense
					+ ", pan=" + pan + "]";
		}
		public Emp() {
			super();
		}
		public Emp(int id, String name, String email, int salary, String designation, String aadhar, String mobile,
				String drivinglicense, String pan) {
			super();
			this.id = id;
			this.name = name;
			this.email = email;
			this.salary = salary;
			this.designation = designation;
			this.aadhar = aadhar;
			this.mobile = mobile;
			this.drivinglicense = drivinglicense;
			this.pan = pan;
		}
		public int getId() {
			return id;
		}
		public void setId(int id) {
			this.id = id;
		}
		public String getName() {
			return name;
		}
		public void setName(String name) {
			this.name = name;
		}
		public String getEmail() {
			return email;
		}
		public void setEmail(String email) {
			this.email = email;
		}
		public int getSalary() {
			return salary;
		}
		public void setSalary(int salary) {
			this.salary = salary;
		}
		public String getDesignation() {
			return designation;
		}
		public void setDesignation(String designation) {
			this.designation = designation;
		}
		public String getAadhar() {
			return aadhar;
		}
		public void setAadhar(String aadhar) {
			this.aadhar = aadhar;
		}
		public String getMobile() {
			return mobile;
		}
		public void setMobile(String mobile) {
			this.mobile = mobile;
		}
		public String getDrivinglicense() {
			return drivinglicense;
		}
		public void setDrivinglicense(String drivinglicense) {
			this.drivinglicense = drivinglicense;
		}
		public String getPan() {
			return pan;
		}
		public void setPan(String pan) {
			this.pan = pan;
		}

		
}
