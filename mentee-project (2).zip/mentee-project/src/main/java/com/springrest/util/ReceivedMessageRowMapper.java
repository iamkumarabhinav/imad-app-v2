package com.springrest.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.springrest.model.Message;

public class ReceivedMessageRowMapper implements RowMapper<Message> {

	@Override
	public Message mapRow(ResultSet rs, int rowNum) throws SQLException {
		Message tempMessage=new Message();
		tempMessage.setEmpId(rs.getInt(1));
		tempMessage.setMsg(rs.getString(3));
		return tempMessage;
	}

}
