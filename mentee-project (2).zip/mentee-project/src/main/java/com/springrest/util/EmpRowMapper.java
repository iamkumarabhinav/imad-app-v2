package com.springrest.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;

import com.springrest.model.Emp;

public class EmpRowMapper implements RowMapper<Emp> {

	@Override
	public Emp mapRow(ResultSet rs, int rowNum) throws SQLException {
		Emp tempEmp=new Emp();
		tempEmp.setId(rs.getInt(1));
		tempEmp.setName(rs.getString(2));
		tempEmp.setSalary(rs.getInt(8));
		tempEmp.setDesignation(rs.getString(9));
		tempEmp.setEmail(rs.getString(3));
		tempEmp.setAadhar(rs.getString(4));
		tempEmp.setDrivinglicense(rs.getString(6));
		tempEmp.setPan(rs.getString(7));
		tempEmp.setMobile(rs.getString(5));
		return tempEmp;
	}

}
