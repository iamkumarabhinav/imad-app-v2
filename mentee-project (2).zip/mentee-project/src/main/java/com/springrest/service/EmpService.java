package com.springrest.service;

import java.util.List;

import com.springrest.model.Emp;
import com.springrest.model.Message;

public interface EmpService {

	List<Emp> getAllEmployees();

	Emp getEmployeeById(int id);

	void save(Emp emp);

	void delete(int id);

	void update(int id, Emp emp);

	Message getMessageById(int id);

	void updateMsg(int id, Message msg);

	Message getManagerMessageById(int id);

	void updateMsgToManager(int id, Message msg);

}
