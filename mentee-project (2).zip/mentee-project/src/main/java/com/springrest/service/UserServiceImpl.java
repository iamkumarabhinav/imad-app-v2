package com.springrest.service;

public class UserServiceImpl implements UserService {

}
