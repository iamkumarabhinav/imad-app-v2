package com.springrest.service;

public interface UserService {

}
