package com.springrest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.springrest.dao.*;
import com.springrest.model.Emp;
import com.springrest.model.Message;

@Service
public class EmpServiceImpl implements EmpService {

	@Autowired
	private EmpDao empDao;

	@Override
	public List<Emp> getAllEmployees() {
		return empDao.getAllEmployees();
	}

	@Override
	public Emp getEmployeeById(int id) {
		return empDao.getEmployeeById(id);
	}

	@Override
	public void save(Emp emp) {
		empDao.save(emp);
	}

	@Override
	public void delete(int id) {
		empDao.delete(id);
	}

	@Override
	public void update(int id, Emp emp) {
		// TODO Auto-generated method stub
		empDao.update(id, emp);
	}

	@Override
	public Message getMessageById(int id) {
		// TODO Auto-generated method stub
		return empDao.getMessageById(id);
	}

	@Override
	public void updateMsg(int id, Message msg) {
		// TODO Auto-generated method stub
		empDao.updateMsg(id, msg);
	}

	@Override
	public Message getManagerMessageById(int id) {
		// TODO Auto-generated method stub
		return empDao.getManagerMessageById(id);
	}

	@Override
	public void updateMsgToManager(int id, Message msg) {
		// TODO Auto-generated method stub
		empDao.updateMsgToManager(id, msg);
	}
}
