package com.springdemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import com.springdemo.entity.Question;
import com.springdemo.service.QuestionService;

@Controller
@RequestMapping("/question")
public class QuestionController {
	
	@Autowired
	private QuestionService questionService;
	
	@RequestMapping("/list")
	public String listQuestions(Model theModel){
		
		List<Question> theQuestions = questionService.getQuestions();
		theModel.addAttribute("questions",theQuestions);
		return "question-page";
	}

}
