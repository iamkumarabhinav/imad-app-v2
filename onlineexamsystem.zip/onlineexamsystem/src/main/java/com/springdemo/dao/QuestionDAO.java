package com.springdemo.dao;
import java.util.List;
import com.springdemo.entity.Question;

public interface QuestionDAO {
	
	public List<Question> getQuestions();

}
