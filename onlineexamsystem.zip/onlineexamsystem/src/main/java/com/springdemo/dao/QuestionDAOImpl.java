package com.springdemo.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.springdemo.entity.Question;

@Repository
public class QuestionDAOImpl implements QuestionDAO {

	 
	private Connection connection;
    private CallableStatement cst=null;
    private PreparedStatement pst=null;
    private ResultSet rst=null;
    boolean  flag=false;
    Statement stmt = null;
    int c=0;

	public QuestionDAOImpl() {
		
		connection = DBUtil.getConnection();
        if(connection!=null)
                        System.out.println("connection done");
        else
                        System.out.println("not done");

	}



	public List<Question> getQuestions() 
	{
		List<Question> QSet=new ArrayList<Question>();
		try {
			stmt = connection.createStatement();
		} catch (SQLException e) {
			e.printStackTrace();
		}
        try {
			rst=stmt.executeQuery("select * from question380");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
        try {
			while(rst.next())
			{
				int tQuesno=rst.getInt(1);
				String tQues=rst.getString(2);
				String tOpt1=rst.getString(3);
				String tOpt2=rst.getString(4);
				String tOpt3=rst.getString(5);
				String tOpt4=rst.getString(6);
				int tAns=rst.getInt(7);
				int tMarks=rst.getInt(8);
				int tCid=rst.getInt(9);
				Question q=new Question(tQuesno,tQues,tOpt1,tOpt2,tOpt3,tOpt4,tAns,tMarks,tCid);
				QSet.add(q);
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		return QSet;
	}

}
