package com.springdemo.dao;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;
public class DBUtil 
{
	 private static Connection connection = null;
	    public static Connection getConnection() {
	        if (connection != null)
	            return connection;
	        else {
	            try {
	            	DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
					String url="jdbc:oracle:thin:@10.232.71.29:1521:INATP02";
					connection=DriverManager.getConnection(url,"Shobana","Shobana");
	            }
	          
	            catch (SQLException e) {
	                e.printStackTrace();
	            } 
	           
	            return connection;
	        }
	    }
	
}
