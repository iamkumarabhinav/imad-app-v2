package com.springdemo.service;
import java.util.List;

import com.springdemo.entity.Question;

public interface QuestionService {

	public List<Question> getQuestions(); 
}
