package com.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.springrest.service.EmpService;
import com.springrest.model.Emp;
import com.springrest.model.Message;

@RestController
public class EmpRestController {

	@Autowired
	private EmpService empService;
	
	
	/*
	 *URI for Hr to get details of all employees 
	 */
	@GetMapping("/employees")
	public List<Emp> getAllEmployees() {
		return empService.getAllEmployees();
	}

	
	/*
	 *URI for Hr to get details of an employee by Id 
	 */
	@GetMapping("/employees/{id}")
	public ResponseEntity<Object> getEmployee(@PathVariable("id") int id) {
		Emp emp = empService.getEmployeeById(id);
		if (emp == null) {
			return new ResponseEntity<Object>("No Employee found for ID " + id, HttpStatus.NOT_FOUND);
		} 
		return new ResponseEntity<Object>(emp, HttpStatus.OK);
	}
	
	

	/*
	 *URI for Employee to register his details(add an employee) 
	 */
	@PostMapping(value = "/employees")
	public ResponseEntity<Object> insertEmployee(@RequestBody Emp emp) {
		empService.save(emp);
		return new ResponseEntity<Object>(emp, HttpStatus.OK);
	}
	
	

	/*
	 *URI for HR or an Employee to delete an employee 
	 */
	@DeleteMapping("/employees/{id}")
	public ResponseEntity<Object> deleteEmployee(@PathVariable("id") int id) {
		empService.delete(id);
		return new ResponseEntity<Object>("Employee deleted with ID " + id, HttpStatus.OK);
	}

	/*
	 *URI for HR or an Employee to delete an employee 
	 */
	@PutMapping("/employees/{id}")
	public ResponseEntity<Object> updateEmployee(@PathVariable int id, @RequestBody Emp emp) {
		empService.update(id, emp);
		return new ResponseEntity<Object>("Employee udpated with ID " + id, HttpStatus.OK);
	}
	
	
	/*
	 *URI for HR to view messages received from an employee 
	 */
	@GetMapping("/employees/{id}/messages")
	public ResponseEntity<Object> getMessage(@PathVariable("id") int id) {
		Message msg = empService.getMessageById(id);
		if (msg == null) {
			return new ResponseEntity<Object>("No Received Message found for ID " + id, HttpStatus.NOT_FOUND);
		} 
		return new ResponseEntity<Object>(msg, HttpStatus.OK);
	}
	
	
	/*
	 *URI for HR to send messages to an employee 
	 */
	@PutMapping("/employees/{id}/messages")
	public ResponseEntity<Object> updateMessage(@PathVariable int id, @RequestBody Message msg) {
		empService.updateMsg(id, msg);
		return new ResponseEntity<Object>("Message Sent to Employee with ID " + id, HttpStatus.OK);
	}
	
	
	
}









