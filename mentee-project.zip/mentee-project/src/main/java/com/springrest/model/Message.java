package com.springrest.model;

public class Message {
	public Message() {
		super();
	}
	public Message(int empId, String msg) {
		super();
		EmpId = empId;
		this.msg = msg;
	}
	@Override
	public String toString() {
		return "Message [EmpId=" + EmpId + ", msg=" + msg + "]";
	}
	private int EmpId;
	private String msg;
	public int getEmpId() {
		return EmpId;
	}
	public void setEmpId(int empId) {
		EmpId = empId;
	}
	public String getMsg() {
		return msg;
	}
	public void setMsg(String msg) {
		this.msg = msg;
	}

}
