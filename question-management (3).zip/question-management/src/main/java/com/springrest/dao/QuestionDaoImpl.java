package com.springrest.dao;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;


import com.springrest.model.Question;
import com.springrest.util.QuestionRowMapper;

public class QuestionDaoImpl implements QuestionDao {
	
	@Autowired
	private JdbcTemplate template;

	public QuestionDaoImpl() {
		super();
	}

	public QuestionDaoImpl(JdbcTemplate template) {
		super();
		this.template = template;
	}

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}

	@Override
	public List<Question> getAllQuestions() {
		// TODO Auto-generated method stub
		List<Question> allQuestions=null;
		String query="SELECT * FROM Question1280";
		System.out.println(query);
		allQuestions=template.query(query,new QuestionRowMapper());
		return allQuestions;
	}

	@Override
	public Question getQuestionByNum(int num) {
		// TODO Auto-generated method stub
		Question foundQuestion=null;
		String query="SELECT * FROM Question1280 WHERE Qno=" + num;
		System.out.println(query);
		foundQuestion=template.queryForObject(query,new QuestionRowMapper());
		return foundQuestion;
	}

	@Override
	public int save(Question ques) {
		// TODO Auto-generated method stub
		String query="INSERT INTO Question1280 VALUES ("+ques.getQno()+",'"+ques.getQuestion()+"','"+ques.getOpt1()+"','"+ques.getOpt2()+"','"+ques.getOpt3()+"','"+ques.getOpt4()+"',"+ques.getAnswer()+","+ques.getMarks()+",'"+ques.getCname()+"')";
		System.out.println(query);
	    return template.update(query);
	}

	@Override
	public int delete(int num) {
		// TODO Auto-generated method stub
		String query="DELETE FROM Question1280 WHERE Qno=" + num;
		System.out.println(query);
		return template.update(query);
	}

	@Override
	public int update(int num, Question ques) {
		// TODO Auto-generated method stub
		String query="UPDATE Question1280 SET Question='"+ques.getQuestion()+"', Opt1='"+ques.getOpt1()+"', Opt2='"+ques.getOpt2()+"', Opt3='"+ques.getOpt3()+"', Opt4='"+ques.getOpt4()+"', Answer="+ques.getAnswer()+", Marks="+ques.getMarks()+", cname='"+ques.getCname()+"' where Qno="+ques.getQno();
		System.out.println(query);		
		return template.update(query);
	}
	
	
	
	
	
	

}
