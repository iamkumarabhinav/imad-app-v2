package com.springrest.dao;

import java.util.List;

import com.springrest.model.Question;

public interface QuestionDao {

	List<Question> getAllQuestions();

	Question getQuestionByNum(int num);

	int save(Question ques);

	int delete(int num);

	int update(int num, Question ques);

}
