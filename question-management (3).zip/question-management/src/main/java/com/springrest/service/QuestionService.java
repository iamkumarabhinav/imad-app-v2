package com.springrest.service;

import java.util.List;

import com.springrest.model.Question;

public interface QuestionService {

	List<Question> getAllQuestions();

	Question getQuestionByNum(int num);

	void save(Question ques);

	void delete(int num);

	void update(int num, Question ques);

	



}
