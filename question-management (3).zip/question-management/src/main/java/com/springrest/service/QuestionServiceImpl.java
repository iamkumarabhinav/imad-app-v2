package com.springrest.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springrest.dao.QuestionDao;
import com.springrest.model.Question;

@Service
public class QuestionServiceImpl implements QuestionService {
	
	@Autowired
	private QuestionDao questionDao;

	@Override
	public List<Question> getAllQuestions() {
		// TODO Auto-generated method stub
		return questionDao.getAllQuestions();
	}

	@Override
	public Question getQuestionByNum(int num) {
		// TODO Auto-generated method stub
		return questionDao.getQuestionByNum(num);
	}

	@Override
	public void save(Question ques) {
		// TODO Auto-generated method stub
		questionDao.save(ques);
	}

	@Override
	public void delete(int num) {
		// TODO Auto-generated method stub
		questionDao.delete(num);
	}

	@Override
	public void update(int num, Question ques) {
		// TODO Auto-generated method stub
		questionDao.update(num,ques);
	}
}
