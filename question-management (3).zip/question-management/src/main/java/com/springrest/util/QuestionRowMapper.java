package com.springrest.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.springrest.model.Question;

public class QuestionRowMapper implements RowMapper<Question> {

	@Override
	public Question mapRow(ResultSet rs, int rowNum) throws SQLException {
		Question tempQuestion=new Question();
		tempQuestion.setQno(rs.getInt(1));
		tempQuestion.setQuestion(rs.getString(2));
		tempQuestion.setOpt1(rs.getString(3));
		tempQuestion.setOpt2(rs.getString(4));
		tempQuestion.setOpt3(rs.getString(5));
		tempQuestion.setOpt4(rs.getString(6));
		tempQuestion.setAnswer(rs.getInt(7));
		tempQuestion.setMarks(rs.getInt(8));
		tempQuestion.setCname(rs.getString(9));
		return tempQuestion;
	}

}
