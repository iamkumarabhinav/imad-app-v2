package com.springrest.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;


import com.springrest.model.Question;
import com.springrest.service.QuestionService;

@RestController
public class QuestionRestController {
	
	@Autowired
	private QuestionService questionService;
	
	
	@GetMapping("/questions")
	public List<Question> getAllQuestions() {
		return questionService.getAllQuestions();
	}
	
	@GetMapping("/questions/{num}")
	public ResponseEntity<Object> getQuestionloyee(@PathVariable("num") int num) {
		Question ques = questionService.getQuestionByNum(num);
		if (ques == null) {
			return new ResponseEntity<Object>("No Question found for number " + num, HttpStatus.NOT_FOUND);
		} 
		return new ResponseEntity<Object>(ques, HttpStatus.OK);
	}
	
	@PostMapping(value = "/questions")
	public ResponseEntity<Object> insertQuestion(@RequestBody Question ques) {
		questionService.save(ques);
		return new ResponseEntity<Object>(ques, HttpStatus.OK);
	}
	
	
	@DeleteMapping("/questions/{num}")
	public ResponseEntity<Object> deleteQuestion(@PathVariable("num") int num) {
		questionService.delete(num);
		return new ResponseEntity<Object>("Question deleted with num " + num, HttpStatus.OK);
	}
	
	@PutMapping("/questions/{num}")
	public ResponseEntity<Object> updateQuestion(@PathVariable int num, @RequestBody Question ques) {
		questionService.update(num, ques);
		return new ResponseEntity<Object>("Question udpated with num " + num, HttpStatus.OK);
	}
	
}
