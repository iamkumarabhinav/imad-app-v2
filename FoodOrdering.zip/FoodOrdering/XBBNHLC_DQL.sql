
-- Select statements and procedures for XBBNHLC_CUSTOMER_DETAILS

select * from xbbnhlc_customer_details;
Select custid,firstname,lastname,dob,contact_no,address,city,state,pincode,email,password
from xbbnhlc_customer_details;

create or replace procedure insertCustomerDetails_201294(custid IN number,firstname IN varchar2, lastname IN varchar2,dob IN date,
contact_no IN number,address IN varchar2, city IN varchar2, state IN varchar2, pincode IN number, email IN varchar2, password IN varchar2)
AS
BEGIN
INSERT INTO XBBNHLC_CUSTOMER_DETAILS values(custid,firstname,lastname,dob,contact_no,address,city,state,pincode,email,password);
END;

Create or replace procedure updateCustomerDetails_201294(id IN number,fname IN varchar2, lname IN varchar2,dofb IN date,
contactno IN number,addr IN varchar2, cty IN varchar2, stat IN varchar2, pin IN number, mail IN varchar2, pass IN varchar2) 
AS
BEGIN
UPDATE XBBNHLC_CUSTOMER_DETAILS
set custid=id,firstname=fname,lastname=lname,dob=dofb,contact_no=contactno,address=addr,city=cty,state=stat,pincode=pin,email=mail,password=pass;
end updateCustomerDetails_201294;

Create or replace procedure deleteCustomerDetails_201294(id IN number)
AS
BEGIN
DELETE from XBBNHLC_CUSTOMER_DETAILS where custid=id;
end;


exec deleteCustomerDetails_201294(6);
exec insertCustomerDetails_201294(6,'Tanveer','Azam',TO_DATE('1995-02-02','YYYY-MM-DD'),9245678910,'303,Sector-9','Chandigarh','Punjab',134908,'tanveer9211@gmail.com','tannedveer');
-------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

-- Select statements and procedures for XBBNHLC_ADMIN_DETAILS

Select adminid,firstname,lastname,contact_no,email,password
from xbbnhlc_admin_details;

create or replace procedure insertAdminDetails_201294(adminid IN number,firstname IN varchar2,lastname IN varchar2,contact_no IN number,
email IN varchar2,password IN varchar2)
AS
BEGIN
INSERT INTO XBBNHLC_ADMIN_DETAILS values(adminid,firstname,lastname,contact_no,email,password);
END;

Create or replace procedure updateAdminDetails_201294(id IN number,fname IN varchar2, lname IN varchar2,
contactno IN number, mail IN varchar2, pass IN varchar2) 
AS
BEGIN
UPDATE XBBNHLC_ADMIN_DETAILS
set adminid=id,firstname=fname,lastname=lname,contact_no=contactno,email=mail,password=pass;
end updateAdminDetails_201294;
----------------------------------------------------------------------------------------------------------------------------------------------------------

-- Select statements and procedures for XBBNHLC_MENU

CREATE OR REPLACE PROCEDURE viewMenu_201294(afm 
as
begin
select * from xbbnhlc_menu;
end;


Select menu_id,menu_type,description,price
from xbbnhlc_menu;

create or replace procedure insertMenu_201294(menu_id IN number,menu_type IN varchar2,description IN varchar2,price IN number)
AS
BEGIN
INSERT INTO XBBNHLC_MENU values(menu_id,menu_type,description,price);
END;

Create or replace procedure updateMenu_201294(id IN number,type IN varchar2, descrp IN varchar2,
prc IN float) 
AS
BEGIN
UPDATE XBBNHLC_MENU
set menu_id=id,menu_type=type,description=descrp,price=prc;
end updateMenu_201294;

Create or replace procedure deleteMenu_201294(id IN number)
AS
BEGIN
DELETE from XBBNHLC_MENU where menu_id=id;
end;
----------------------------------------------------------------------------------------------------------------------------------------------------------

-- Select statements and procedures for XBBNHLC_ORDER

Select order_id,custid,bill,qty
from xbbnhlc_order;

create or replace procedure insertOrder_201294(order_id IN number,custid IN number,bill IN number,qty IN number)
AS
BEGIN
INSERT INTO XBBNHLC_ORDER values(order_id,custid,bill,qty);
END;

Create or replace procedure updateOrder_201294(id IN number,cid IN number, amt IN number,
quantity IN number) 
AS
BEGIN
UPDATE XBBNHLC_ORDER
set order_id=id,custid=cid,bill=amt,qty=quantity;
end updateOrder_201294;

Create or replace procedure deleteOrder_201294(id IN number)
AS
BEGIN
DELETE from XBBNHLC_ORDER where order_id=id;
end;
----------------------------------------------------------------------------------------------------------------------------------------------------------
commit;

----------------------------------------------------------------------------------------------------------------------------------------------------------
--Add new customer

create or replace procedure insertCustomerDetails_201294(custid IN number,firstname IN varchar2, lastname IN varchar2,dob IN date,
contact_no IN number,address IN varchar2, city IN varchar2, state IN varchar2, pincode IN number, email IN varchar2, password IN varchar2)
AS
BEGIN
INSERT INTO XBBNHLC_CUSTOMER_DETAILS values(custid,firstname,lastname,dob,contact_no,address,city,state,pincode,email,password);
END;



---------------------------------------------------------------------------------------------------------------------------------------------------------
--View Menu

create or replace procedure 
viewMenu201294(serv OUT sys_refcursor)IS 
begin 
  open serv for select * from xbbnhlc_menu; 
end viewMenu201294;

----------------------------------------------------------------------------------------------------------------------------------------------------------
--View Customer

create or replace procedure
viewCustomer201294(serv OUT sys_refcursor)IS
begin
  open serv for select * from xbbnhlc_customer_details;
end viewCustomer201294;

----------------------------------------------------------------------------------------------------------------------------------------------------------
--Edit Menu

create or replace procedure edit_menu_lc(mid in number, mtype in varchar2, descrp in varchar2, pric in float) as
begin
update xbbnhlc_menu set menu_type=mtype,description=descrp,price=pric where menu_id=mid;
commit;
end;


update xbbnhlc_menu set menu_type='aa',description='a',price=2.0 where menu_id=501;
var aa number;
var bb varchar2;
var cc varchar2;
var dd varchar2;
execute edit_menu_lc(502,'Non Veg','Non Vegetarian Platter',1400.0);

select * from xbbnhlc_menu;
commit;

drop procedure  edit_menu_lc;
-----------------------------------------------------------------------------------------------------------------------------------------------------------
--Delete Menu

create or replace procedure delete_menu_lc(mid in number) as
begin
delete xbbnhlc_menu where menu_id=mid;
commit;
end;

execute delete_menu_lc('213');
-----------------------------------------------------------------------------------------------------------------------------------------------------------

--menu_id number primary key,
--menu_type varchar2(30) not null,
--description varchar2(300) not null,
--price float not null

-----------------------------------------------------------------------------------------------------------------------------------------------------------
--Add Menu

CREATE OR REPLACE PROCEDURE add_menu_201294(mid number,mtype varchar2,descrp varchar2,pric number) AS
BEGIN
INSERT INTO XBBNHLC_MENU VALUES(mid,mtype,descrp,pric);

-----------------------------------------------------------------------------------------------------------------------------------------------------------
--To fetch ROLE 
create or replace procedure abcd_294(eml in varchar2, pass in varchar2, rol out varchar2 ) as
begin
select role into rol from xbbnhlc_login where email=eml and password=pass;
end;

------------------------------------------------------------------------------------------------------------------------------------------------------------

--To insert in the order table

create or replace procedure insertOrders_201294(order_id IN number,custid IN number,bill IN number)
AS 
BEGIN
insert into XBBNHLC_ORDERS values(order_id,custid,bill);
end;


select * from XBBNHLC_ORDERS;

select * from XBBNHLC




select * from xbbnhlc_login;

DESC XBBNHLC_LOGIN;
END;

execute add_menu_201294('213','sfhdi','fsdsdf','324');
COMMIT;

select * from XBBNHLC_MENU;
select * from XBBNHLC_CUSTOMER_DETAILS;
desc XBBNHLC_CUSTOMER_DETAILS;
select * from XBBNHLC_orders2012;
select * from XBBNHLC_LOGIN;