
--Insertion in XBBNHLC_CUSTOMER_DETAILS

insert into xbbnhlc_customer_details values(1,'Ishita','Kapoor',TO_DATE('1995-09-24','YYYY-MM-DD'),9855404947,'651,Sector-2','Panchkula','Haryana',134112,'shtkpr95@gmail.com','ishi12345');
insert into xbbnhlc_customer_details values(2,'Naina','Anand',TO_DATE('1995-06-07','YYYY-MM-DD'),7837324766,'180,Sector-15','Panchkula','Haryana',134115,'naina95anand@gmail.com','ishi12345');
insert into xbbnhlc_customer_details values(3,'Smridhi','Batra',TO_DATE('1994-12-13','YYYY-MM-DD'),9876039489,'389,Sector-8','Panchkula','Haryana',134116,'smridhibatra95@gmail.com','simsim123');
insert into xbbnhlc_customer_details values(4,'Aastha','Suyal',TO_DATE('1995-04-08','YYYY-MM-DD'),7087421027,'38,Sector-35','Chandigarh','Punjab',134908,'suyalaastha@gmail.com','aastha3490');
insert into xbbnhlc_customer_details values(5,'Anmol','Dadhwal',TO_DATE('1995-05-12','YYYY-MM-DD'),8968992320,'908,Sector-17','Panchkula','Haryana',134134,'dadwalanmol95@gmail.com','12anmol98');

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--Insertion in XBBNHLC_ADMIN_DETAILS

insert into xbbnhlc_admin_details values(101,'Nancy','Singha',7986817645,'nancysingha95@gmail.com','singha98765');
insert into xbbnhlc_admin_details values(102,'Divya','Malhotra',9465225912,'malhotra95divya@gmail.com','div34mal90');
insert into xbbnhlc_admin_details values(103,'Aarushi','Bhola',8699506439,'bhola95@gmail.com','aarus123bhola');
insert into xbbnhlc_admin_details values(104,'Prameet','Kaur',9087654312,'kaurmeet@gmail.com','kaurmeet98765');
insert into xbbnhlc_admin_details values(105,'Vanita','Verma',9872445688,'vverma95@gmail.com','vverma98765');

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

select * from xbbnhlc_menu;
--Insertion in XBBNHLC_MENU

insert into xbbnhlc_menu values(501,'Veg','Vegetarian Platter',1200.0);
insert into xbbnhlc_menu values(502,'Non Veg','Non Vegetarian Platter',1400.0);
insert into xbbnhlc_menu values(503,'Veg','Middle East Bites',475.0);
insert into xbbnhlc_menu values(504,'Veg','Vegetarian Pasta',370.0);
insert into xbbnhlc_menu values(505,'Non Veg','Chicken Pasta',400.0);

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--Insertion in XBBNHLC_ORDER

insert into xbbnhlc_order values(1001,2,1675,2);
insert into xbbnhlc_order values(1002,1,740,2);
insert into xbbnhlc_order values(1003,5,2275,3);
insert into xbbnhlc_order values(1004,3,475,1);
insert into xbbnhlc_order values(1005,4,1200,1);

select * from xbbnhlc_order;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
commit;

--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------

--Insertion in Login Table

insert into xbbnhlc_login values('nancysingha95@gmail.com','singha98765','admin');
insert into xbbnhlc_login values('shtkpr95@gmail.com','ishi12345','customer');
insert into xbbnhlc_login values('naina95anand@gmail.com','ishi12345','customer');
select * from xbbnhlc_login;
--------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
commit;


select * from xbbnhlc_menu;
create or replace procedure abcd_294(eml in varchar2, pass in varchar2, rol out varchar2 ) as
begin
select role into rol from xbbnhlc_login where email=eml and password=pass;
end;



