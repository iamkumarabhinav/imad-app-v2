
drop table XBBNHLC_ORDER;
drop table XBBNHLC_MENU;
drop table XBBNHLC_CUSTOMER_DETAILS;
drop table XBBNHLC_ADMIN_DETAILS;
drop table 
--------------------------------------------------------------------------------------------------------------------------------------------------------
--Customer Details

create table XBBNHLC_CUSTOMER_DETAILS(
custid number primary key,
firstname varchar2(50) not null,
lastname varchar2(50) not null,
dob date not null,
contact_no number not null,
address varchar2(50) not null,
city varchar2(30) not null,
state varchar2(30) not null,
pincode number not null,
email varchar2(60) not null,
password varchar2(30) not null
);

select * from XBBNHLC_CUSTOMER_DETAILS;

--------------------------------------------------------------------------------------------------------------------------------------------------------
--Admin Details

create table XBBNHLC_ADMIN_DETAILS(
adminid number primary key,
firstname varchar2(50) not null,
lastname varchar2(50) not null,
contact_no number not null,
email varchar2(60) not null,
password varchar2(30) not null
);

--------------------------------------------------------------------------------------------------------------------------------------------------------
--Menu Details
 select * from xbbnhlc_menu;
create table XBBNHLC_MENU(
menu_id number primary key,
menu_type varchar2(30) ,
description varchar2(300) ,
price number not null
);

---------------------------------------------------------------------------------------------------------------------------------------------------------
--Order Details

create table XBBNHLC_ORDER(
order_id number primary key,
custid references XBBNHLC_CUSTOMER_DETAILS(custid),
bill float not null,
qty number not null
);

----------------------------------------------------------------------------------------------------------------------------------------------------------

--Order Table

create table XBBNHLC_ORDERS(
order_id number primary key,
custid references XBBNHLC_CUSTOMER_DETAILS(custid),
bill number not null
);

create table XBBNHLC_ORDER2012(
order_id number primary key,
custid varchar2(255),
bill number not null
);

select * from XBBNHLC_ORDER2012;

delete from xbbnhlc_order2012 where order_id IN(2,3);
--Login Details


COMMIT;