package com.demo.beans;

public class orderfood {
public int getOrderfoodid() {
		return orderfoodid;
	}
	public void setOrderfoodid(int orderfoodid) {
		this.orderfoodid = orderfoodid;
	}
	public int getFoodid() {
		return foodid;
	}
	public void setFoodid(int foodid) {
		this.foodid = foodid;
	}
	public int getQuantity() {
		return quantity;
	}
	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}
	public int getTotalprice() {
		return totalprice;
	}
	public void setTotalprice(int totalprice) {
		this.totalprice = totalprice;
	}
private int orderfoodid;
private int foodid;
private int quantity;
private int totalprice;
}
