package com.demo.beans;

public class food {
	private int foodid;  
	private String foodname;
	private String foodpreference;
    private int foodprice;
    private String fooddescription;
    private String foodtype;


    public food() {
		super();
	}

	public food(int foodid, String foodname, String foodpreference, int foodprice, String fooddescription,String foodtype) {
		super();
		this.foodid = foodid;
		this.foodname = foodname;
		this.foodpreference = foodpreference;
		this.foodprice = foodprice;
		this.fooddescription = fooddescription;
		this.foodtype = foodtype;
	}

	public int getFoodid() {
		return foodid;
	}

	public void setFoodid(int foodid) {
		this.foodid = foodid;
	}

	public String getFoodname() {
		return foodname;
	}

	public void setFoodname(String foodname) {
		this.foodname = foodname;
	}

	public String getFoodpreference() {
		return foodpreference;
	}

	public void setFoodpreference(String foodpreference) {
		this.foodpreference = foodpreference;
	}

	public int getFoodprice() {
		return foodprice;
	}

	public void setFoodprice(int foodprice) {
		this.foodprice = foodprice;
	}

	public String getFooddescription() {
		return fooddescription;
	}

	public void setFooddescription(String fooddescription) {
		this.fooddescription = fooddescription;
	}

	public String getFoodtype() {
		return foodtype;
	}

	public void setFoodtype(String foodtype) {
		this.foodtype = foodtype;
	}




}
