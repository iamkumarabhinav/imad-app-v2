package com.demo.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.SQLException;

import com.demo.beans.register;

public class Registerationdao {

    private static Connection connection;
//     private static boolean flag=false;
//     private static int c=0;
    private CallableStatement cst=null;
    public Registerationdao()
    {
           connection = DBUtil.getMyConnection();
           if(connection!=null)

      System.out.println("connection done");

else

      System.out.println("connection not done");

}

    
       public void adduser(register register) 
       {
                   try 
                   {
                      cst = connection.prepareCall("{call adduser(?,?,?,?,?,?,?,?)}");
                      cst.setInt(1,register.getUserid());
                      cst.setString(2,register.getUsername());
                      cst.setString(3,register.getPass());
                      cst.setString(4,register.getUserrole());
                      cst.setInt(5,register.getAge());
                      cst.setInt(6,register.getContact());
                      cst.setString(7,register.getEmail());
                      cst.setString(8,register.getAddress());
                     cst.execute();
                   }
                   catch (SQLException e)
                   {
                           e.printStackTrace();
                   }
           
       }


	

}
