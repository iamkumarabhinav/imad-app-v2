

package com.demo.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import oracle.jdbc.driver.OracleTypes;

import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Service;

import com.demo.beans.food;


@Service
public class fooddao {
                
                
                private CallableStatement cst;
    private Connection connection;
    
    public fooddao(){
          connection = DBUtil.getMyConnection();
    }
 /* JdbcTemplate template;
    public void setTemplate(JdbcTemplate template) {
                                this.template = template;
                }

                public int save(food p) {
                                String sql = "insert into FOOD, values(" + p.getFoodid() + ",'"
                                                                + p.getFoodname() + "'," + p.getFoodpreference() + ",'" +p.getFoodprice() + ",'" + p.getFooddescription() + ",'"
                                                                + p.getFoodtype() + ",'" ;
                                return template.update(sql);
                }

         
                
                public int update(food p) {
 
                    String sql = "update FOOD set foodname='" + p.getFoodname()

                    + "', foodpreference=" + p.getFoodpreference() + ",foodprice='" + p.getFoodprice()

                    + "',fooddescription=" + p.getFooddescription() + ",foodtype='" + p.getFoodtype()

                    + "where foodid=" + p.getFoodid()

                    + "";

 return template.update(sql);

            }



                public int delete(int foodid) {
                                String sql = "delete from FOOD where food_id=" + foodid + "";
                                return template.update(sql);
                };

                public food getfoodById(int foodid) {
                                String sql = "select * from FOOD where food_id=?";
                                return template.queryForObject(sql, new Object[] { foodid },
                                                                new BeanPropertyRowMapper<food>(food.class));
                }

                public List<food> getfood() {
                                return template.query("select * from FOOD",
                                                                new RowMapper<food>() {
                                                                                public food mapRow(ResultSet rs, int row)
                                                                                                                throws SQLException {
                                                                                                food e = new food();
                                                                                                e.setFoodid(rs.getInt(1));
                                                                                                e.setFoodname(rs.getString(2));
                                                                                                e.setFoodpreference(rs.getString(3));
                                                                                                e.setFoodprice(rs.getInt(4));
                                                                                                e.setFooddescription(rs.getString(5));
                                                                                                e.setFoodtype(rs.getString(6));
                                                                                               

                                                                                                return e;
                                                                                }
                                                                }); 
                }
              

*/
                public List<food> getAllEssays() {
        
        List<food> content=new ArrayList<food>();
        try{
               
               Statement statement=connection.createStatement();
               ResultSet rs=statement.executeQuery("Select * from FOOD");
               if(rs!=null){
                      
                      System.out.println("Found");
                      
               }
               else{
                      System.out.println("Not Found");
                      
               }
while(rs.next()){
  
  food product=new food();
  
  product.setFoodid(rs.getInt(1)); 
  product.setFoodname(rs.getString(2)); 
  product.setFoodpreference(rs.getString(3)); 
  product.setFoodprice(rs.getInt(4)); 
  product.setFooddescription(rs.getString(5)); 
  product.setFoodtype(rs.getString(6)); 

 
  
  content.add(product);
}

        }
        
        catch(SQLException e)
        {
        	e.printStackTrace();
        	}
return content;                   
               

} 
                
                
                
                
                
                
                
                /* update food */                             
                public void updatefood(food food) {
                    try 
                    {
                       System.out.println("In Dao");
                       cst = connection.prepareCall("{call updateFood(?,?,?,?,?,?)}");
                       cst.setInt(1, food.getFoodid());
                       cst.setString(2, food.getFoodname());   
                       cst.setString(3, food.getFoodpreference());
                       cst.setInt(4, food.getFoodprice());
                       cst.setString(5, food.getFooddescription());
                       cst.setString(6, food.getFoodtype());
                       cst.execute();
                    }
                    catch (SQLException e)
                    {
                             e.printStackTrace();
                    }}
           
                
                
                
               /*ADD FOOD*/ 
                
                
                
                public void addfood(food food) {

                    try 

                    {

                    	   cst = connection.prepareCall("call addFood(?,?,?,?,?,?)");
                           cst.setInt(1, food.getFoodid());
                           cst.setString(2, food.getFoodname());   
                           cst.setString(3, food.getFoodpreference());
                           cst.setInt(4, food.getFoodprice());
                           cst.setString(5, food.getFooddescription());
                           cst.setString(6, food.getFoodtype());
                           cst.execute();

                    }

                    catch (SQLException e)

                    {

                          e.printStackTrace();

                    }
                    
                }
                



/*delete food*/


                public void deletefood(food food) {

                    try 

                    {

                            System.out.println("In Dao");

                       cst = connection.prepareCall("{call deleteFood(?)}");

                       cst.setInt(1, food.getFoodid());

                       cst.execute();

                    }

                    catch (SQLException e)

                    {

                             e.printStackTrace();

                    }

                    }
}

                
                
       

                
                

                
                
                
                
                
                
                
                
                
                
                


