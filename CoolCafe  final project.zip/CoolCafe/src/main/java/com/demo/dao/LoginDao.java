package com.demo.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.stereotype.Service;

import com.demo.beans.Login;

@Service
public class LoginDao {

	private static Connection connection;

	private static boolean flag = false;

	private static int c = 0;

	public LoginDao() {

		connection = DBUtil.getMyConnection();

	}

	public static boolean validate(Login login) {

		try {

			PreparedStatement cst = connection.prepareStatement("select * from user201313 where userid=? and pass=?");

			cst.setInt(1, login.getUserId());

			cst.setString(2, login.getPassword());

			ResultSet rs = cst.executeQuery();

			if (rs.next())

			{

				c++;

				System.out.println(c);

				flag = true;

			}

			else

				flag = false;

		} catch (SQLException e) {

			// TODO Auto-generated catch block

			e.printStackTrace();

		}

		return flag;

	}

}
