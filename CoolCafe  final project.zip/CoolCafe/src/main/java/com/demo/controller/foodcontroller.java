package com.demo.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.expression.ParseException;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;


import com.demo.beans.food;
import com.demo.dao.fooddao;




@RestController
public class foodcontroller {
                
                
                fooddao dao= new fooddao();
                @RequestMapping("foodsaveform/")  
    public ModelAndView showform(){  
        return new ModelAndView("foodsaveform","command",new food());  
    } 
                @RequestMapping(value="/save",method=RequestMethod.POST)
                public ModelAndView save(@ModelAttribute("food") food food ){
                                dao.save(food );
                                return new ModelAndView("redirect:/viewfood");
                                
                }
                @RequestMapping(value="/viewfood",method=RequestMethod.GET)
                public ModelAndView  viewfood(){
                                List<food> list=dao.getfood();
                                return new ModelAndView("viewfood","list",list);
                }
                @RequestMapping(value="/editfood/{foodid}")  
    public ModelAndView edit(@PathVariable int id){  
        food food=dao.getfoodById(id);  
        return new ModelAndView("foodedit","command",food);  
    }  
                @RequestMapping(value="/editsave",method = RequestMethod.POST)  
    public ModelAndView editsave(@ModelAttribute("food") food food){  
        dao.update(food);  
        return new ModelAndView("redirect:/viewfood");  
    }  
 
   
    
    
                
                /*VIEW FOOD*/

@RequestMapping(value="/services",method=RequestMethod.GET)
public List<food> getEssays(){
       List<food> cnts=new ArrayList<food>();
       cnts=dao.getAllEssays();
       System.out.println("in controller class");
       return cnts; 
}









/* update food */


@RequestMapping(value="/update/{foodid}/{foodname}/{foodpreference}/{foodprice}/{fooddescription}/{foodtype}",method = RequestMethod.POST)
public void updatefood(@PathVariable int foodid,@PathVariable String foodname,@PathVariable String foodpreference,@PathVariable int foodprice,@PathVariable String fooddescription,@PathVariable String foodtype){ 
        System.out.println("In controller");
        food food=new food();
        food.setFoodid(foodid);
        food.setFoodname(foodname);
        food.setFoodpreference(foodpreference);
        food.setFoodprice(foodprice);
        food.setFooddescription(fooddescription);
        food.setFoodtype(foodtype);
        dao.updatefood(food);      
}  




/*ADD FOOD*/

@RequestMapping(value="/add/{foodid}/{foodname}/{foodpreference}/{foodprice}/{fooddescription}/{foodtype}",method = RequestMethod.POST)

public void addfood(@PathVariable int foodid,@PathVariable String foodname,@PathVariable String foodpreference,@PathVariable int foodprice,@PathVariable String fooddescription,@PathVariable String foodtype) { 

	   food food=new food();
       food.setFoodid(foodid);
       food.setFoodname(foodname);
       food.setFoodpreference(foodpreference);
       food.setFoodprice(foodprice);
       food.setFooddescription(fooddescription);
       food.setFoodtype(foodtype);
       dao.addfood(food);   

}



/*Delete food*/

@RequestMapping(value="/deleteFood/{foodid}",method = RequestMethod.POST)

public void deletefood(@PathVariable int foodid) throws ParseException { 

System.out.println("In controller");

    food food=new food();

food.setFoodid(foodid);

dao.deletefood(food);

}

}







