package com.demo.controller;
//import oracle.sql.DATE;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;
import com.demo.beans.register;
import com.demo.dao.Registerationdao;
@RestController
public class RegisterationController {
    Registerationdao rd= new Registerationdao();
  @RequestMapping(value="/login/insert/{userid}/{username}/{pass}/{userrole}/{age}/{contact}/{email}/{address}",method = RequestMethod.POST)
    public void addUser(@PathVariable int userid,@PathVariable String username,@PathVariable String pass,@PathVariable String userrole,@PathVariable int age,@PathVariable int contact,@PathVariable String email,@PathVariable String address){ 
    register login=new register();
    login.setUserid(userid);
    login.setUsername(username);
    login.setPass(pass);
    login.setUserrole(userrole);
    login.setAge(age);
    login.setContact(contact);
    login.setEmail(email);
    login.setAddress(address);
    rd.adduser(login); 
    }
}

        

         

   