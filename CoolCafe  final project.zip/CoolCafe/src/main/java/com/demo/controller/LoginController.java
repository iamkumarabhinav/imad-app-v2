package com.demo.controller;

import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.demo.beans.Login;
import com.demo.dao.LoginDao;

@RestController
public class LoginController {
	 LoginDao logindao=new LoginDao();

     

     @RequestMapping(value="/validation/{userid}/{pass}",method=RequestMethod.POST)

     public boolean validation(@PathVariable int userid,@PathVariable String pass){

             Login login=new Login();

             login.setUserId(userid);

             login.setPassword(pass);

    boolean valid=LoginDao.validate(login);

         return valid;

     }


}
