package com.informatica.mdm.cs.sample.AddressCode;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.informatica.mdm.sample.cs.ADMCommon;
import com.informatica.mdm.sample.cs.ADMDataSource;
import com.informatica.mdm.sample.cs.BE;
import com.informatica.mdm.sample.cs.BEConstants;
import com.informatica.mdm.sample.cs.BELocalLanguageGeneric;
import com.informatica.mdm.sample.cs.BETargetSystemGeneric;
import com.informatica.mdm.sample.cs.DataSet.DataSet;

// if there is a pending record it will get the pending state
public class AddressCode {
	String RowId = "";
	String BECode = "";
	String BEDesc = "";
	Date BEActiveDate = null;
	Date BEInactiveDate = null;
	String BEHubState = "";
	Boolean BECodeFound = false;
	DataSet BEDataSet = null;
	
	// DataSet theDataSet = null;
	List<BETargetSystemGeneric> lstBETargetSystem = new ArrayList<BETargetSystemGeneric>();
	List<BELocalLanguageGeneric> lstBELocalLanguage = new ArrayList<BELocalLanguageGeneric>();

	private static final Logger LOGGER = Logger.getLogger(AddressCode.class);

	public BE getBE(Object parmRowId, Object parmBECode, BEConstants parmBEConstants) {
		String strRowId = "";
		String strBECode = "";
		
		if (parmRowId != null) {
			strRowId = parmRowId.toString();
		}
		if (parmBECode != null) {
			strBECode = parmBECode.toString();
		}

		LoadBE(strRowId);
		LoadBECodeFound(strBECode); // LOOK FOR EXISTING BECODE EVEN IF NEW RECORD
		BEDataSet = new DataSet(parmBEConstants.BE_DATA_SET);

		if (!RowId.equals("")) {
			LoadBELocalLanguage();
			LoadBETargetSystem();
		}

		BE objBE = new BE(RowId, BECode, BEDesc, BEActiveDate, BEInactiveDate, BEHubState, BECodeFound, lstBETargetSystem, lstBELocalLanguage, BEDataSet);

		return objBE;
	}

	public void LoadBE(String parmValue) {
		if (parmValue != null) {
			String selectQuery = "";

			selectQuery = "SELECT A.ROWID_OBJECT, ISNULL(B.APTERM_CD,A.APTERM_CD) BE_CD, ISNULL(B.APTERM_DESC,A.APTERM_DESC) BE_DESC, ISNULL(B.ACT_DATE,A.ACT_DATE) ACT_DATE, ISNULL(B.INACT_DATE,A.INACT_DATE) INACT_DATE, ISNULL(B.HUB_STATE_IND, A.HUB_STATE_IND) HUB_STATE "
					+ "FROM C_BO_APTERM A LEFT JOIN C_BO_APTERM_XREF B ON A.ROWID_OBJECT = B.ROWID_OBJECT AND B.HUB_STATE_IND IN (0) WHERE RTRIM(A.ROWID_OBJECT) = RTRIM(?) ";

			ResultSet rs = null;

			try (Connection connection = ADMDataSource.GetDatasource().getConnection(); PreparedStatement prepStmt = connection.prepareStatement(selectQuery);) {
				prepStmt.setString(1, parmValue);
				rs = prepStmt.executeQuery();

				if (rs.next()) {
					RowId = rs.getString("ROWID_OBJECT").trim();
					BECode = rs.getString("BE_CD").trim();
					BEDesc = ADMCommon.CheckforNull(rs.getString("BE_DESC")).trim();
					BEActiveDate = rs.getDate("ACT_DATE");
					BEInactiveDate = rs.getDate("INACT_DATE");
					BEHubState = rs.getString("HUB_STATE");
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.info(e.getMessage());
			} finally {
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException e) {
						e.printStackTrace();
						LOGGER.info(e.getMessage());
					}
				}
			}
		}
	}

	public void LoadBECodeFound(String parmValue) {
		if (parmValue != null) {
			String selectQuery = "";
			ResultSet rs = null;

			selectQuery = "SELECT 'Y' RECFOUND FROM C_BO_APTERM A LEFT JOIN C_BO_APTERM_XREF B ON A.ROWID_OBJECT = B.ROWID_OBJECT AND B.HUB_STATE_IND = 0 "
					+ "WHERE RTRIM(A.APTERM_CD) = RTRIM(?) AND A.HUB_STATE_IND IN (0,1) ";

			try (Connection connection = ADMDataSource.GetDatasource().getConnection(); PreparedStatement prepStmt = connection.prepareStatement(selectQuery);) {

				prepStmt.setString(1, parmValue);
				rs = prepStmt.executeQuery();

				if (rs.next()) {
					BECodeFound = true;
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.info(e.getMessage());
			} finally {
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException e) {
						e.printStackTrace();
						LOGGER.info(e.getMessage());
					}
				}
			}
		}
	}

	private void LoadBELocalLanguage() {
		ResultSet rs = null;

		String selectQuery = "SELECT A.ROWID_OBJECT, ISNULL(B.LANG_ID_FK,A.LANG_ID_FK) LANG_ID, ISNULL(B.LOC_LANG_DESC,A.LOC_LANG_DESC) LANG_DESC, ISNULL(B.ACTIVE_IND,A.ACTIVE_IND) ACT_IND, ISNULL(B.HUB_STATE_IND,A.HUB_STATE_IND) HUB_STATE "
				+ "FROM C_BO_APTERM_LOC_LANG A LEFT JOIN C_BO_APTERM_LOC_LANG_XREF B ON A.ROWID_OBJECT = B.ROWID_OBJECT AND B.HUB_STATE_IND = 0 WHERE RTRIM(A.APTERM_ID_FK) = RTRIM(?) ";

		try (Connection connection = ADMDataSource.GetDatasource().getConnection(); PreparedStatement prepStmt = connection.prepareStatement(selectQuery);) {
			prepStmt.setString(1, RowId);
			rs = prepStmt.executeQuery();

			while (rs.next()) {
				String rowId = rs.getString("ROWID_OBJECT");
				String langId = rs.getString("LANG_ID");
				String langDesc = rs.getString("LANG_DESC");
				String actInd = rs.getString("ACT_IND");
				String hubState = rs.getString("HUB_STATE");

				lstBELocalLanguage.add(new BELocalLanguageGeneric(rowId, langId, langDesc, actInd, hubState));
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info(e.getMessage());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
					LOGGER.info(e.getMessage());
				}
			}
		}
	}

	private void LoadBETargetSystem() {
		ResultSet rs = null;

		String selectQuery = "SELECT A.ROWID_OBJECT, ISNULL(B.DATA_SET_TGT_SYS_ID_FK,A.DATA_SET_TGT_SYS_ID_FK) TGT_SYS, ISNULL(B.TGT_SYS_REC_ID,A.TGT_SYS_REC_ID) REC_ID, "
				+ "ISNULL(B.TGT_SYS_REC_CD,A.TGT_SYS_REC_CD) REC_CD, ISNULL(B.ACTIVE_IND,A.ACTIVE_IND) ACT_IND, ISNULL(B.HUB_STATE_IND,A.HUB_STATE_IND) HUB_STATE  "
				+ "FROM C_BO_APTERM_TGT_SYS A LEFT JOIN C_BO_APTERM_TGT_SYS_XREF B ON A.ROWID_OBJECT = B.ROWID_OBJECT AND B.HUB_STATE_IND = 0 WHERE RTRIM(A.APTERM_ID_FK) = RTRIM(?) ";

		try (Connection connection = ADMDataSource.GetDatasource().getConnection(); PreparedStatement prepStmt = connection.prepareStatement(selectQuery);) {
			prepStmt.setString(1, RowId);
			rs = prepStmt.executeQuery();

			while (rs.next()) {
				String rowId = rs.getString("ROWID_OBJECT");
				String tgtSys = rs.getString("TGT_SYS");
				String recId = ADMCommon.CheckforNull(rs.getString("REC_ID"));
				String recCd = ADMCommon.CheckforNull(rs.getString("REC_CD"));
				String actInd = rs.getString("ACT_IND");
				String hubState = rs.getString("HUB_STATE");

				lstBETargetSystem.add(new BETargetSystemGeneric(rowId, tgtSys, recId, recCd, actInd, hubState));
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info(e.getMessage());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
					LOGGER.info(e.getMessage());
				}
			}
		}
	}
}
