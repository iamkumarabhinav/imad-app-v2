package com.informatica.mdm.cs.sample.AddressCode;

import com.informatica.mdm.sample.cs.BEConstants;

public class AddressCodeConstants {

	public static BEConstants getConstants() {

		BEConstants objBEConstants = new BEConstants();

		objBEConstants.BE_CLASS_NAME = "AddressCode";
		objBEConstants.BE_ERROR_OBJECT = "Accounts Payable Terms";
		objBEConstants.BE_ERROR_FIELD = "AddressCodeView.AddressCode.label";
		objBEConstants.BE_DATA_SET = "AddressCode";

		// BE
		objBEConstants.CLM_BE_ROWID = "AddressCode/rowidObject";
		objBEConstants.CLM_BE_ACTIVE = "AddressCode/Active";
		objBEConstants.CLM_BE_SITE = "AddressCode/Site";
		objBEConstants.CLM_BE_FACILITY = "AddressCode/Facility";
		objBEConstants.CLM_BE_SUPPLEMENTAL = "AddressCode/Supplemental";
		
		// BE Address Code MNA
		objBEConstants.SBJ_BE_ADDRESS_CODE_MNA = "AddressCode/AddressCodeMNA/item";
		objBEConstants.CLM_BE_MNA_ROWID = "rowidObject";
		objBEConstants.CLM_BE_MNA_ORGID = "OrgId"; 
		objBEConstants.CLM_BE_MNA_ADDRESS_CODE = "LanguageFK/rowidObject"; 
		objBEConstants.CLM_BE_CUP_FK = "AddressCodeCUPFK/rowidObject"; 
		
		return objBEConstants;
	}
}
