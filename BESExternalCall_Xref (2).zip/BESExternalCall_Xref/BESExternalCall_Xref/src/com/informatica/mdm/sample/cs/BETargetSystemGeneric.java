package com.informatica.mdm.sample.cs;

public class BETargetSystemGeneric {

	public String rowID = "";
	public String targetSysCode = "";
	public String recordId = "";
	public String recordCode = "";
	public String actInd = "";
	public String hubState = "";

	public BETargetSystemGeneric(String RowID, String TargetSysCode, String RecordId, String RecordCode, String ActInd, String HubState) {
		rowID = RowID.trim();
		targetSysCode = TargetSysCode.trim();
		recordId = RecordId.trim();
		recordCode = RecordCode.trim();
		actInd = ActInd.trim();
		hubState = HubState.trim();
	}
}
