package com.informatica.mdm.sample.cs;

public class BELocalLanguageGeneric {

	public String rowID = "";
	public String langId = "";
	public String langDesc = "";
	public String actInd = "";
	public String hubState = "";

	public BELocalLanguageGeneric(String RowID, String LangId, String LangDesc, String ActInd, String HubState) {
		rowID = RowID.trim();
		langId = LangId.trim();
		langDesc = LangDesc.trim();
		actInd = ActInd.trim();
		hubState = HubState.trim();
	}
}
