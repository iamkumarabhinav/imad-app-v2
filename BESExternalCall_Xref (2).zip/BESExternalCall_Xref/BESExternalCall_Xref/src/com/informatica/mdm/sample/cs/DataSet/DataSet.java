package com.informatica.mdm.sample.cs.DataSet;

import java.util.ArrayList;
import java.util.List;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import org.apache.log4j.Logger;

import com.informatica.mdm.sample.cs.ADMCommon;
import com.informatica.mdm.sample.cs.ADMDataSource;

// if there is a pending record it will get the pending state
public class DataSet {
	public String RowId = "";
	public String BEDataSetCode = "";
	public String BEName = "";
	public String BEDesc = "";
	public String Active = "";
	public String CategoryCode = "";
	public String BEHubState = "";
	public boolean BECodeFound = false;

	public List<DataSetTargetSystem> lstBETargetSystem = new ArrayList<DataSetTargetSystem>();
	public List<DataSetApprover> lstBEApprover = new ArrayList<DataSetApprover>();

	private static final Logger LOGGER = Logger.getLogger(DataSet.class);

	public DataSet(Object dataSetCode) {
		LoadBE(null, dataSetCode.toString());
	}

	public DataSet(Object rowId, Object objBEDataSetCode) {
		String dataSetCode = "";
		if (objBEDataSetCode != null) {
			dataSetCode = objBEDataSetCode.toString();
		}
		LoadBE(rowId, dataSetCode);
	}

	public void LoadBE(Object beRowid, String strBEDataSetCode) {

		if (beRowid != null || !strBEDataSetCode.equalsIgnoreCase("")) {
			if (beRowid != null) {
				RowId = beRowid.toString();
			}

			BEDataSetCode = strBEDataSetCode;
			String selectQuery = "SELECT A.ROWID_OBJECT, ISNULL(B.DATA_SET_CD,A.DATA_SET_CD) DATA_SET_CD, ISNULL(B.DATA_SET_NAME,A.DATA_SET_NAME) DATA_SET_NAME, "
					+ "ISNULL(B.DATA_SET_DESC,A.DATA_SET_DESC) DATA_SET_DESC, ISNULL(B.ACTIVE_IND,A.ACTIVE_IND) ACTIVE_IND, ISNULL(B.DATA_SET_CTGRY_CD,A.DATA_SET_CTGRY_CD) DATA_SET_CTGRY_CD, "
					+ "ISNULL(B.HUB_STATE_IND,A.HUB_STATE_IND) HUB_STATE "
					+ "FROM C_BT_DATA_SET A LEFT JOIN C_BT_DATA_SET_XREF B ON A.ROWID_OBJECT = B.ROWID_OBJECT AND B.HUB_STATE_IND IN (0) WHERE RTRIM(A.ROWID_OBJECT) = RTRIM(?) OR RTRIM(A.DATA_SET_CD) = RTRIM(?) ";

			ResultSet rs = null;

			try (Connection connection = ADMDataSource.GetDatasource().getConnection(); PreparedStatement prepStmt = connection.prepareStatement(selectQuery);) {

				prepStmt.setString(1, RowId);
				prepStmt.setString(2, BEDataSetCode);
				rs = prepStmt.executeQuery();

				if (rs.next()) {
					RowId = rs.getString("ROWID_OBJECT").trim();
					BEDataSetCode = rs.getString("DATA_SET_CD").trim();
					BEName = rs.getString("DATA_SET_NAME").trim();
					BEDesc = rs.getString("DATA_SET_DESC").trim();
					Active = rs.getString("ACTIVE_IND").trim();
					CategoryCode = rs.getString("DATA_SET_CTGRY_CD").trim();
					BEHubState = rs.getString("HUB_STATE").trim();
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.info(e.getMessage());
			} finally {
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException e) {
						e.printStackTrace();
						LOGGER.info(e.getMessage());
					}
				}
			}

			if (!RowId.equals("")) {
				LoadDataSetApprovers();
				LoadDataSetTargetSystem();
			}
		}

		LoadBECodeFound(strBEDataSetCode); // LOOK FOR EXISTING BECODE EVEN IF NEW RECORD
	}

	private void LoadDataSetApprovers() {
		String selectQuery = "SELECT A.ROWID_OBJECT, ISNULL(B.APPR_ORD,A.APPR_ORD) APPR_ORD, "
				+ "ISNULL(B.APPR_ROLE_ID_FK,A.APPR_ROLE_ID_FK) APPR_ROLE, ISNULL(B.ACTIVE_IND,A.ACTIVE_IND) ACT_IND, ISNULL(B.HUB_STATE_IND,A.HUB_STATE_IND) HUB_STATE FROM C_BT_DATA_SET_APPR A LEFT JOIN C_BT_DATA_SET_APPR_XREF B ON A.ROWID_OBJECT = B.ROWID_OBJECT AND B.HUB_STATE_IND IN (0) "
				+ "WHERE RTRIM(A.DATA_SET_ID_FK) = RTRIM(?) AND A.HUB_STATE_IND IN (0,1) ";

		ResultSet rs = null;

		try (Connection connection = ADMDataSource.GetDatasource().getConnection(); PreparedStatement prepStmt = connection.prepareStatement(selectQuery);) {

			prepStmt.setString(1, RowId);
			rs = prepStmt.executeQuery();

			while (rs.next()) {
				lstBEApprover.add(new DataSetApprover(rs.getString("ROWID_OBJECT"), rs.getString("APPR_ROLE"), rs.getString("APPR_ORD"), rs.getString("ACT_IND"), rs.getString("HUB_STATE")));
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info(e.getMessage());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
					LOGGER.info(e.getMessage());
				}
			}
		}
	}

	public void LoadBECodeFound(String parmValue) {
		if (parmValue != null) {
			String selectQuery = "";
			ResultSet rs = null;

			selectQuery = "SELECT 'Y' RECFOUND FROM C_BT_DATA_SET A LEFT JOIN C_BT_DATA_SET B ON A.ROWID_OBJECT = B.ROWID_OBJECT AND B.HUB_STATE_IND IN (0) "
					+ "WHERE RTRIM(A.DATA_SET_CD) = RTRIM(?) AND A.HUB_STATE_IND IN (0,1) ";

			try (Connection connection = ADMDataSource.GetDatasource().getConnection(); PreparedStatement prepStmt = connection.prepareStatement(selectQuery);) {

				prepStmt.setString(1, parmValue);
				rs = prepStmt.executeQuery();

				if (rs.next()) {
					BECodeFound = true;
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.info(e.getMessage());
			} finally {
				if (rs != null) {
					try {
						rs.close();
					} catch (SQLException e) {
						e.printStackTrace();
						LOGGER.info(e.getMessage());
					}
				}
			}
		}
	}

	private void LoadDataSetTargetSystem() {
		String selectQuery = "SELECT A.ROWID_OBJECT, ISNULL(B.DATA_SET_CD,A.DATA_SET_CD) DATA_SET_CD, ISNULL(B.TGT_SYS_CD,A.TGT_SYS_CD) TGT_SYS, "
				+ "ISNULL(B.REQ_TGT_SYS_IND,A.REQ_TGT_SYS_IND) REQ_SYS, ISNULL(B.CRS_REF_MAN_ENTR_IND,A.CRS_REF_MAN_ENTR_IND) XREF_MAN, ISNULL(B.EMAIL_NOTIF,A.EMAIL_NOTIF) EMAIL, "
				+ "ISNULL(B.ACTIVE_IND,A.ACTIVE_IND) ACT_IND, ISNULL(B.HUB_STATE_IND,A.HUB_STATE_IND) HUB_STATE FROM C_BT_DATA_SET_TGT_SYS A LEFT JOIN C_BT_DATA_SET_TGT_SYS_XREF B ON A.ROWID_OBJECT = B.ROWID_OBJECT AND B.HUB_STATE_IND IN (0) "
				+ "WHERE RTRIM(A.DATA_SET_CD) = RTRIM(?) AND A.HUB_STATE_IND IN (0,1) ";

		ResultSet rs = null;

		try (Connection connection = ADMDataSource.GetDatasource().getConnection(); PreparedStatement prepStmt = connection.prepareStatement(selectQuery);) {

			prepStmt.setString(1, BEDataSetCode);
			rs = prepStmt.executeQuery();

			while (rs.next()) {
				lstBETargetSystem.add(new DataSetTargetSystem(rs.getString("ROWID_OBJECT"), rs.getString("DATA_SET_CD"), rs.getString("TGT_SYS"), rs.getString("REQ_SYS"), rs.getString("XREF_MAN"),
						ADMCommon.CheckforNull(rs.getString("EMAIL")), rs.getString("ACT_IND"), rs.getString("HUB_STATE")));
			}
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info(e.getMessage());
		} finally {
			if (rs != null) {
				try {
					rs.close();
				} catch (SQLException e) {
					e.printStackTrace();
					LOGGER.info(e.getMessage());
				}
			}
		}
	}

	public String GetTargetSystemSysIdFromRowID(String RowID) {
		for (DataSetTargetSystem targSys : lstBETargetSystem) {
			if (targSys.rowID.equalsIgnoreCase(RowID)) {
				return targSys.targetSysCode;
			}
		}
		return "";
	}

	public String GetRoleNameFromRowID(String RowID) {
		for (DataSetApprover approver : lstBEApprover) {
			if (approver.rowID.equalsIgnoreCase(RowID)) {
				return approver.AddressCode;
			}
		}
		return "";
	}
}
