package com.informatica.mdm.sample.cs.DataSet;

public class DataSetConstants {

	public final String BE_CLASS_NAME = "DataSet";
	public final  String BE_ERROR_OBJECT = "Data Set";
	public final String BE_ERROR_FIELD = "DataSet.label";

	// BE
	public final String CLM_BE_ROWID = "DataSet/rowidObject";
	public final String CLM_BE_CODE = "DataSet/DataSetCode";
	public final int CLM_BE_CODE_MIN_LENGTH = 1;
	public final int CLM_BE_CODE_MAX_LENGTH = 20;
	public final String CLM_BE_NAME = "DataSet/DataSetName";
	public final String CLM_BE_DESC = "DataSet/DataSetDesc";
	public final String CLM_BE_ACT = "DataSet/Active";
	public final String CLM_BE_EMAIL = "DataSet/EmailNotification";

	// BE Cross Reference System
	public final String SBJ_BE_TARGET_SYSTEM = "DataSet/DataSetTargetSystemRel/item";
	public final String CLM_BE_TS_ROWID = "rowidObject";
	public final String CLM_BE_TS_FK_ROWID = "TargetSystemCode/rowidObject";
	public final String CLM_BE_TS_FK_CODE = "TargetSystemCode/TargetSystemCode";
	public final String CLM_BE_TS_REQ_SYS = "RequiredTargetSystem";
	public final String CLM_BE_TS_XREF_MAN = "CrossReferenceManualEntry";
	public final String CLM_BE_TS_EMAIL = "EmailNotification";
	public final String CLM_BE_TS_ACT = "Active";

	// BE Approver
	public final String SBJ_BE_APPROVER = "DataSet/DataSetApproverRel/item";
	public final String CLM_BE_AP_ROWID = "rowidObject";
	public final String CLM_BE_AP_ROLE_FK_ROWID = "AddressCodeName/rowidObject";
	public final String CLM_BE_AP_ROLE_FK_ROLE = "AddressCodeName/RoleName";
	public final String CLM_BE_AP_APPR_ORD = "ApprovalOrder";
	public final int CLM_BE_AP_APPR_ORD_MIN = 1;
	public final String CLM_BE_AP_ACT = "Active";
}
