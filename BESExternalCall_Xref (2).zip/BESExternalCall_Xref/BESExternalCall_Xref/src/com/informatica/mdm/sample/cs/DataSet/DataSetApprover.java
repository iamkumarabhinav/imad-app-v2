package com.informatica.mdm.sample.cs.DataSet;

public class DataSetApprover {

	public String rowID = "";
	public String AddressCode = "";
	public String approvalOrder = "";
	public String actInd = "";
	public String hubState = "";

	public DataSetApprover(String RowID, String AddressCode, String ApprovalOrder, String ActInd, String HubState) {

		rowID = RowID.trim();
		AddressCode = AddressCode.trim();
		approvalOrder = ApprovalOrder.trim();
		actInd = ActInd.trim();
		hubState = HubState.trim();
	}
}
