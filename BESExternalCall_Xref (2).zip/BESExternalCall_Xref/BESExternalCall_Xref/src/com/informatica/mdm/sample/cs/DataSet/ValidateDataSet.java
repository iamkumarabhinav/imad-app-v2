package com.informatica.mdm.sample.cs.DataSet;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.informatica.mdm.sdo.cs.base.ValidationError;
import com.informatica.mdm.sdo.cs.base.ValidationErrors;
import com.informatica.mdm.spi.cs.StepException;
import com.informatica.mdm.spi.externalcall.CustomLogic;
import commonj.sdo.DataObject;
import commonj.sdo.helper.DataFactory;
import commonj.sdo.helper.HelperContext;

/**
 * This is piece of logic for validating "DataSet" Business Entity.
 */
public class ValidateDataSet implements CustomLogic {

	private final Logger LOGGER = Logger.getLogger(ValidateDataSet.class);

	@Override
	public DataObject process(HelperContext helperContext, DataObject inputSdo, Map<String, Object> inParams, Map<String, Object> outParams) throws StepException {

		List<ValidationError> errorList = new ArrayList<>();
		DataFactory dataFactory = helperContext.getDataFactory();

		// save button got pressed
		if (inParams.get("validateOnly") == null) {

			List<ValidationError> validationHolderList;

			try {
				DataSetConstants objConstants = new DataSetConstants();
				DataSet objBE = new DataSet(inputSdo.get(objConstants.CLM_BE_ROWID), inputSdo.get(objConstants.CLM_BE_CODE));
				ADMDataSet objBEValidate = new ADMDataSet(helperContext, inputSdo, objConstants, objBE);

				// record has a pending change
				validationHolderList = objBEValidate.CheckPendingChanges(inParams);
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

				// Check BE duplicate
				validationHolderList = objBEValidate.CheckBEDup();
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

				// Check BE Code length
				validationHolderList = objBEValidate.CheckLength(objConstants.CLM_BE_CODE, "Code");
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

				// Check BE Code noise char
				validationHolderList = objBEValidate.CheckNoisyChar(objConstants.CLM_BE_CODE, "Code");
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

				// Check BE Code space char
				validationHolderList = objBEValidate.CheckSpaceChar(objConstants.CLM_BE_CODE, "Code");
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

				// Check BE Desc noise char
				validationHolderList = objBEValidate.CheckNoisyChar(objConstants.CLM_BE_NAME, "Name");
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

				// Check BE Name noise char
				validationHolderList = objBEValidate.CheckNoisyChar(objConstants.CLM_BE_NAME, "Name");
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

				// Check BE Email format
				validationHolderList = objBEValidate.ChecBEEmailFormat();
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

				// Check Approval Order duplicates
				validationHolderList = objBEValidate.CheckApprovalOrderValue(objConstants.CLM_BE_AP_APPR_ORD_MIN);
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

				// Check Approval Order duplicates
				validationHolderList = objBEValidate.CheckApprovalOrderDup();
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

				// Check Cross Reference System duplicates
				validationHolderList = objBEValidate.CheckTargetSystemDup();
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

				// Check Cross Reference System email format
				validationHolderList = objBEValidate.CheckTargetSystemEmailFormat();
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

				// cannot change BE Code once record is created
				validationHolderList = objBEValidate.CheckBECodeCannotChange();
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

				// cannot change Approver Role
				validationHolderList = objBEValidate.CheckAddressCodeCannotChange();
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

				// cannot change Cross Reference System - System ID
				validationHolderList = objBEValidate.CheckTargetSystemSysIdCannotChange();
				if (validationHolderList.size() > 0)
					errorList.addAll(validationHolderList);

			} catch (Exception e) {
				LOGGER.error("Main Error in " + getClass().getEnclosingClass() + ".process");
				LOGGER.error("Error Message " + e.getMessage());
				ValidationErrors errors = (ValidationErrors) dataFactory.create(ValidationErrors.class);
				throw new StepException((DataObject) errors, "ADM-CUSTOM-00001");
			}
		}
		if (errorList.size() > 0) {
			ValidationErrors errors = (ValidationErrors) dataFactory.create(ValidationErrors.class);
			errors.setError(errorList);
			throw new StepException((DataObject) errors, "SIP-50022");

		}

		return null;
	}
}
