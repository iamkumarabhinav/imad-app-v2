package com.informatica.mdm.sample.cs;

import java.util.Map;

import org.apache.log4j.Logger;

/*import com.informatica.mdm.sample.cs.EANCategory.ValidateEANCategory;
import com.informatica.mdm.sample.cs.FreightTerm.ValidateFreightTerm;
import com.informatica.mdm.sample.cs.AddressCode.ValidateAddressCode;
import com.informatica.mdm.sample.cs.AddressCode.ValidateAddressCode;
import com.informatica.mdm.sample.cs.CompanyCode.ValidateCompanyCode;
import com.informatica.mdm.sample.cs.Country.ValidateCountry;
import com.informatica.mdm.sample.cs.Currency.ValidateCurrency;
import com.informatica.mdm.sample.cs.DataSet.ValidateDataSet;
import com.informatica.mdm.sample.cs.DocumentType.ValidateDocumentType;
import com.informatica.mdm.sample.cs.EANCategory.ValidateEANCategory;
import com.informatica.mdm.sample.cs.EEOCensusCode.ValidateEEOCensusCode;
import com.informatica.mdm.sample.cs.EEOCode.ValidateEEOCode;
import com.informatica.mdm.sample.cs.EducationLevel.ValidateEducationLevel;
import com.informatica.mdm.sample.cs.EntityType.ValidateEntityType;
import com.informatica.mdm.sample.cs.GlobalProcCategory.ValidateGlobalProcCategory;
import com.informatica.mdm.sample.cs.Language.ValidateLanguage;
import com.informatica.mdm.sample.cs.PackagingType.ValidatePackagingType;
import com.informatica.mdm.sample.cs.State.ValidateState;
import com.informatica.mdm.sample.cs.SupplierType.ValidateSupplierType;
import com.informatica.mdm.sample.cs.TaxNumberType.ValidateTaxNumberType;
import com.informatica.mdm.sample.cs.UNSPSC.ValidateUNSPSC;
import com.informatica.mdm.sample.cs.UnitOfMeasure.ValidateUnitOfMeasure;*/
import com.informatica.mdm.spi.cs.StepException;
import com.informatica.mdm.spi.externalcall.CustomLogic;
import com.informatica.mdm.spi.externalcall.CustomLogicFactory;
import com.informatica.mdm.spi.externalcall.ServicePhase;
import com.informatica.mdm.spi.externalcall.Trigger;
import com.informatica.mdm.spi.externalcall.ExternalCallRequest;
import commonj.sdo.DataObject;
import commonj.sdo.helper.HelperContext;

public class CustomLogicFactoryImpl implements CustomLogicFactory {

	public static final String DATASET = "DataSet";
	public static final String ADDRESSCODE = "AddressCode";
	public static final String COMPANYCODE = "CompanyCode";
	public static final String COUNTRY = "Country";
	public static final String CURRENCY = "Currency";
	public static final String DOCUMENTTYPE = "DocumentType";
	public static final String EANCATEGORY = "EANCategory";
	public static final String EDUCATIONLEVEL = "EducationLevel";
	public static final String EEOCENSUSCODE = "EEOCensusCode";
	public static final String EEOCODE = "EEOCode";
	public static final String ENTITYTYPE = "EntityType";
	public static final String FREIGHTTERM = "FreightTerm";
	public static final String GLOBALPROCCATEGORY = "GlobalProcCategory";
	public static final String LANGUAGE = "Language";
	public static final String PACKAGINGTYPE = "PackagingType";
	public static final String STATE = "State";
	public static final String SUPPLIERTYPE = "SupplierType";
	public static final String TAXNUMBERTYPE = "TaxNumberType";
	public static final String UNITOFMEASURE = "UnitOfMeasure";
	public static final String UNSPSC = "UNSPSC";
	
	private static final CustomLogic EMPTY_LOGIC = new EmptyLogic();
	private final Logger LOGGER = Logger.getLogger(CustomLogicFactoryImpl.class);

	@Override
	public CustomLogic create(ExternalCallRequest externalCallRequest) throws StepException {

		LOGGER.info("Reference Hub CustomLogicFactoryImpl");

		Trigger trigger = externalCallRequest.getTrigger();
		String businessEntity = trigger.getBusinessEntity();
		ServicePhase phase = trigger.getServicePhase();

		LOGGER.info("Phase: " + phase);

		switch (phase) {
		// case WRITE_CO_BEFORE_VALIDATE:
		case WRITE_CO_BEFORE_EVERYTHING:
			/*if (DATASET.equals(businessEntity)) {
				return new ValidateDataSet();
			} else if (AddressCode.equals(businessEntity)) {
				return new ValidateAddressCode();
			} else if (CURRENCY.equals(businessEntity)) {
				return new ValidateCurrency();
			} else if (COUNTRY.equals(businessEntity)) {
				return new ValidateCountry();
			} else if (STATE.equals(businessEntity)) {
				return new ValidateState();
			} else if (LANGUAGE.equals(businessEntity)) {
				return new ValidateLanguage();
			} else if (TAXNUMBERTYPE.equals(businessEntity)) {
				return new ValidateTaxNumberType();
			} else if (AddressCode.equals(businessEntity)) {
				return new ValidateAddressCode();
			} else if (ENTITYTYPE.equals(businessEntity)) {
				return new ValidateEntityType();
			} else if (DOCUMENTTYPE.equals(businessEntity)) {
				return new ValidateDocumentType();
			} else if (SUPPLIERTYPE.equals(businessEntity)) {
				return new ValidateSupplierType();
			} else if (UNSPSC.equals(businessEntity)) {
				return new ValidateUNSPSC();
			} else if (GLOBALPROCCATEGORY.equals(businessEntity)) {
				return new ValidateGlobalProcCategory();
			} else if (COMPANYCODE.equals(businessEntity)) {
				return new ValidateCompanyCode();
			} else if (EEOCODE.equals(businessEntity)) {
				return new ValidateEEOCode();
			} else if (EEOCENSUSCODE.equals(businessEntity)) {
				return new ValidateEEOCensusCode();
			} else if (EDUCATIONLEVEL.equals(businessEntity)) {
				return new ValidateEducationLevel();
			} else if (UNITOFMEASURE.equals(businessEntity)) {
				return new ValidateUnitOfMeasure();
			} else if (PACKAGINGTYPE.equals(businessEntity)) {
				return new ValidatePackagingType();
			} else if (FREIGHTTERM.equals(businessEntity)) {
				return new ValidateFreightTerm();
			} else if (EANCATEGORY.equals(businessEntity)) {
				return new ValidateEANCategory();
			}*/
			break;
		// case MERGE_CO_BEFORE_EVERYTHING:
		default:
			//
		}
		return EMPTY_LOGIC; // this one will do nothing
	}

	private static class EmptyLogic implements CustomLogic {

		public static final DataObject OBJECT = null;

		@Override
		public DataObject process(HelperContext helperContext, DataObject dataObject, Map<String, Object> map, Map<String, Object> map1) throws StepException {
			return OBJECT;
		}
	}
}
