package com.informatica.mdm.sample.cs;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.sql.DataSource;

import org.apache.log4j.Logger;

public class ADMDataSource {
	
	private static final Logger LOGGER = Logger.getLogger(ADMDataSource.class);

	public static DataSource GetDatasource() {

		DataSource dataSource = null;

		try {
			Context ctx = new InitialContext();
			dataSource = (DataSource) ctx.lookup(ADMConstants.DATA_SOURCE);
			
			LOGGER.info("Java Data Source: " + ADMConstants.DATA_SOURCE);
			
			return dataSource;
		} catch (Exception e) {
			e.printStackTrace();
		}

		return null;

	}
}
