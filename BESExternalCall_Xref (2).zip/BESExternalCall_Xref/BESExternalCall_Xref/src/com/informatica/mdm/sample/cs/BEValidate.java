package com.informatica.mdm.sample.cs;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.informatica.mdm.sample.cs.DataSet.DataSetTargetSystem;
import com.informatica.mdm.sdo.cs.base.ValidationError;

import commonj.sdo.DataObject;
import commonj.sdo.helper.HelperContext;

public class BEValidate {

	private final static Logger LOGGER = Logger.getLogger(BEValidate.class);
	private HelperContext helperContext;
	private DataObject inputSdo;
	private BEConstants objConstants;
	private BE objBE;

	public BEValidate(HelperContext parmHelperContext, DataObject parmInputSdo, BEConstants parmConstants, BE parmBE) {
		helperContext = parmHelperContext;
		inputSdo = parmInputSdo;
		objConstants = parmConstants;
		objBE = parmBE;
	}

	// Length validations
	//
	//
	public List<ValidationError> CheckLength(String strValue, String strErrorFieldName) {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckBECodeLength");

		List<ValidationError> errorList = new ArrayList<>();

		if (ADMCommon.CheckLength(inputSdo.get(strValue), objConstants.CLM_BE_CODE_MIN_LENGTH, objConstants.CLM_BE_CODE_MAX_LENGTH)) {
			if (objConstants.CLM_BE_CODE_MIN_LENGTH == objConstants.CLM_BE_CODE_MAX_LENGTH) {
				errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckBECodeLength-00001", objConstants.BE_ERROR_FIELD,
						objConstants.BE_ERROR_OBJECT + " " + strErrorFieldName + " must be " + objConstants.CLM_BE_CODE_MIN_LENGTH + " characters long."));
			} else {
				errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckBECodeLength-00002", objConstants.BE_ERROR_FIELD, objConstants.BE_ERROR_OBJECT + " "
						+ strErrorFieldName + " must be between " + objConstants.CLM_BE_CODE_MIN_LENGTH + " and " + objConstants.CLM_BE_CODE_MAX_LENGTH + " characters long."));
			}
		}

		return errorList;
	}

	// Noisy Char validations
	//
	//
	public List<ValidationError> CheckNoisyChar(String strValue, String strErrorFieldName) {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckBENoisyChar");

		List<ValidationError> errorList = new ArrayList<>();
		Object strFoundValue = inputSdo.get(strValue.toString());

		// check BE Code noisy char
		if (strFoundValue != null) {
			if (ADMCommon.CheckNoisyChar(strFoundValue.toString())) {
				errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckBENoisyChar-00001", objConstants.BE_ERROR_FIELD,
						objConstants.BE_ERROR_OBJECT + " " + strErrorFieldName + " is not valid."));
			}
		}

		return errorList;
	}

	public List<ValidationError> CheckSpaceChar(String strValue, String strErrorFieldName) {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckBENoisyChar");

		List<ValidationError> errorList = new ArrayList<>();
		Object strFoundValue = inputSdo.get(strValue);

		// check BE Code space char
		if (strFoundValue != null) {
			if (ADMCommon.CheckSpaceChar(strFoundValue.toString())) {
				errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckBENoisyChar-00002", objConstants.BE_ERROR_FIELD,
						objConstants.BE_ERROR_OBJECT + " " + strErrorFieldName + " cannot contain spaces."));
			}
		}

		return errorList;
	}

	// Duplicate validations
	//
	//
	public List<ValidationError> CheckBEDup() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckBEDup");

		List<ValidationError> errorList = new ArrayList<>();

		Object objRowid = inputSdo.get(objConstants.CLM_BE_ROWID);
		Object objCode = inputSdo.get(objConstants.CLM_BE_CODE);

		if (objRowid == null && objCode != null) {
			String strCode = objCode.toString();

			try {
				if (objBE.BECodeFound) {
					errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckBEDup-00002", objConstants.BE_ERROR_FIELD,
							objConstants.BE_ERROR_OBJECT + " " + strCode + " is duplicated."));
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.info(e.getMessage());
			}
		}

		return errorList;
	}

	public List<ValidationError> CheckLocalLanguageDup() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckLocalLanguageDup");

		List<ValidationError> errorList = new ArrayList<>();
		List<String> lstLangCode = new ArrayList<String>();
		lstLangCode.clear();

		if (objBE.lstBELocalLanguage != null) {
			try {
				for (BELocalLanguageGeneric locLang : objBE.lstBELocalLanguage) {
					lstLangCode.add(locLang.langId);
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.info(e.getMessage());
			}
		}

		List<DataObject> listLocalLang = inputSdo.getList(objConstants.SBJ_BE_LOCAL_LANGUAGE);
		if (listLocalLang != null && !listLocalLang.isEmpty()) {
			for (DataObject lstLocalLang : listLocalLang) {
				Object objLocalLangRowid = lstLocalLang.get(objConstants.CLM_BE_LL_ROWID);
				Object objLocalLangFkRowid = lstLocalLang.get(objConstants.CLM_BE_LL_FK_ROWID);
				Object objLocalLangFkDesc = lstLocalLang.get(objConstants.CLM_BE_LL_FK_DESC);
				String strLocalLangFkRowid = "";

				if (objLocalLangFkRowid != null) {
					strLocalLangFkRowid = objLocalLangFkRowid.toString().trim();
				}
				// NEW ONE
				if (objLocalLangRowid == null && !strLocalLangFkRowid.isEmpty()) {
					if (lstLangCode.contains(strLocalLangFkRowid)) {
						errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckLocalLanguageDup-00001", objConstants.BE_ERROR_FIELD,
								"Local Language " + objLocalLangFkDesc.toString() + " is duplicated."));
					} else {
						lstLangCode.add(strLocalLangFkRowid);
					}
				}
			}
		}

		return errorList;
	}

	public List<ValidationError> CheckTargetSystemDup() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckTargetSystemDup");

		List<ValidationError> errorList = new ArrayList<>();
		List<String> lstSysCode = new ArrayList<String>();
		lstSysCode.clear();

		if (objBE.lstBETargetSystem != null) {
			try {
				for (BETargetSystemGeneric targSys : objBE.lstBETargetSystem) {
					lstSysCode.add(targSys.targetSysCode);
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.info(e.getMessage());
			}
		}

		List<DataObject> listTargetSys = inputSdo.getList(objConstants.SBJ_BE_TARGET_SYSTEM);
		if (listTargetSys != null && !listTargetSys.isEmpty()) {
			for (DataObject lstTargetSys : listTargetSys) {
				Object objTargetSysRowid = lstTargetSys.get(objConstants.CLM_BE_TS_ROWID);
				Object objTargetSysFkRowid = lstTargetSys.get(objConstants.CLM_BE_TS_FK_ROWID);
				Object objTargetSysFkCode = lstTargetSys.get(objConstants.CLM_BE_TS_FK_CODE);
				String strTargetSysFkRowid = "";

				if (objTargetSysFkRowid != null) {
					strTargetSysFkRowid = objTargetSysFkRowid.toString().trim();
				}
				// NEW ONE
				if (objTargetSysRowid == null && !strTargetSysFkRowid.isEmpty()) {
					if (lstSysCode.contains(strTargetSysFkRowid)) {
						errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckTargetSystemDup-00001", objConstants.BE_ERROR_FIELD,
								"Cross Reference System " + objTargetSysFkCode.toString() + " is duplicated."));
					} else {
						lstSysCode.add(strTargetSysFkRowid);
					}
				}
			}
		}

		return errorList;
	}

	// Required Cross Reference System validations
	//
	//
	public List<ValidationError> CheckTargetSystemRequiredSystem() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckTargetSystemRequiredSystem");

		List<ValidationError> errorList = new ArrayList<>();
		List<String> lstRequiredSys = new ArrayList<String>();
		lstRequiredSys.clear();

		// get list of required Cross Reference Systems
		for (DataSetTargetSystem lstTargetSys : objBE.BEDataSet.lstBETargetSystem) {
			if (lstTargetSys.requiredSystem != null && lstTargetSys.requiredSystem.equals("1") && lstTargetSys.actInd.equals("1")) {
				lstRequiredSys.add(lstTargetSys.rowID);
			}
		}

		// remove existing required Cross Reference Systems
		if (objBE.lstBETargetSystem != null) {
			try {
				for (BETargetSystemGeneric targSys : objBE.lstBETargetSystem) {
					lstRequiredSys.remove(targSys.targetSysCode.trim());
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.info(e.getMessage());
			}
		}

		// remove new required Cross Reference Systems
		List<DataObject> listTargetSys = inputSdo.getList(objConstants.SBJ_BE_TARGET_SYSTEM);
		if (listTargetSys != null && !listTargetSys.isEmpty()) {
			for (DataObject lstTargetSys : listTargetSys) {

				Object objTargetSysRowid = lstTargetSys.get(objConstants.CLM_BE_TS_ROWID);
				Object objTargetSysFKRowid = lstTargetSys.get(objConstants.CLM_BE_TS_FK_ROWID);
				String strTargetSysFKRowid = "";

				if (objTargetSysFKRowid != null) {
					strTargetSysFKRowid = objTargetSysFKRowid.toString().trim();
				}
				// NEW ONE
				if (objTargetSysRowid == null && !strTargetSysFKRowid.isEmpty()) {
					if (lstRequiredSys.contains(strTargetSysFKRowid)) {
						lstRequiredSys.remove(strTargetSysFKRowid);
					}
				}
			}
		}

		// throw error for each required Cross Reference Systems remaining
		for (String lstRequiredTargetSys : lstRequiredSys) {
			for (DataSetTargetSystem lstTargetSys : objBE.BEDataSet.lstBETargetSystem) {
				if (lstRequiredTargetSys.equals(lstTargetSys.rowID)) {
					errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckTargetSystemDup-00001", objConstants.BE_ERROR_FIELD,
							"Cross Reference System " + lstTargetSys.targetSysCode + " is required."));
				}
			}
		}

		return errorList;
	}

	// Cross Reference Manual Entry validations
	//
	//
	public List<ValidationError> CheckTargetSystemXrefManualEntry() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckTargetSystemXrefManualEntry");

		List<ValidationError> errorList = new ArrayList<>();

		List<String> lstNonXrefManualEntrySys = new ArrayList<String>();
		lstNonXrefManualEntrySys.clear();
		// get list of Cross Reference Systems with Cross Reference Manual Entry unchecked
		for (DataSetTargetSystem lstTargetSys : objBE.BEDataSet.lstBETargetSystem) {
			if (lstTargetSys.crossReferenceManualEntry != null && lstTargetSys.crossReferenceManualEntry.equals("0")) {
				lstNonXrefManualEntrySys.add(lstTargetSys.targetSysCode);
			}
		}

		List<DataObject> listTargetSys = inputSdo.getList(objConstants.SBJ_BE_TARGET_SYSTEM);
		if (listTargetSys != null && !listTargetSys.isEmpty()) {
			for (DataObject lstTargetSys : listTargetSys) {

				Object objTargetSysRowid = lstTargetSys.get(objConstants.CLM_BE_TS_ROWID);
				Object objTargetSysFkCode = lstTargetSys.get(objConstants.CLM_BE_TS_FK_CODE);
				Object objTargetSysRecId = lstTargetSys.get(objConstants.CLM_BE_TS_REC_ID);
				Object objTargetSysRecCode = lstTargetSys.get(objConstants.CLM_BE_TS_REC_CODE);
				String strTargetSysRowid = "";
				String strTargetSysFkCode = "";
				String strTargetSysRecId = "";
				String strTargetSysRecCode = "";

				String strTargSysRecIdFound = "";
				String strTargSysRecCodeFound = "";

				if (objTargetSysRowid != null) {
					strTargetSysRowid = objTargetSysRowid.toString();
				}
				if (objTargetSysFkCode != null) {
					strTargetSysFkCode = objTargetSysFkCode.toString();
				}
				if (objTargetSysRecId != null) {
					strTargetSysRecId = objTargetSysRecId.toString();
				}
				if (objTargetSysRecCode != null) {
					strTargetSysRecCode = objTargetSysRecCode.toString();
				}

				// only perform the check if the system is in the list from above
				if (lstNonXrefManualEntrySys.contains(strTargetSysFkCode)) {

					// check for new Cross Reference ID and Code
					if (objTargetSysRowid == null && !strTargetSysFkCode.isEmpty()) {
						if (objTargetSysRecId != null && !strTargetSysRecCode.isEmpty()) {
							errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckTargetSystemXrefManualEntry-00001", objConstants.BE_ERROR_FIELD,
									"Cross Reference System " + strTargetSysFkCode.toString() + " Cross References are not allowed for manual entry."));
						}
					}

					// check for updated Cross Reference ID and Code
					if (objTargetSysRowid != null && !strTargetSysFkCode.isEmpty()) {
						for (BETargetSystemGeneric lstTgtSys : objBE.lstBETargetSystem) {
							if (strTargetSysRowid.equals(lstTgtSys.rowID)) {
								strTargSysRecIdFound = lstTgtSys.recordId;
								strTargSysRecCodeFound = lstTgtSys.recordCode;
							}
						}

						// updated record found with Cross Reference ID and/or Code being updated
						if (!strTargSysRecIdFound.equalsIgnoreCase(strTargetSysRecId) || !strTargSysRecCodeFound.equalsIgnoreCase(strTargetSysRecCode)) {
							errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckTargetSystemXrefManualEntry-00002", objConstants.BE_ERROR_FIELD,
									"Cross Reference System " + objTargetSysFkCode + " Cross References are not allowed for manual entry."));
						}
					}
				}
			}
		}

		return errorList;
	}

	// Cannot change identifying field value
	//
	//
	public List<ValidationError> CheckBECodeCannotChange() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckBECodeCannotChange");

		List<ValidationError> errorList = new ArrayList<>();

		Object rowid = inputSdo.get(objConstants.CLM_BE_ROWID);
		Object beCode = inputSdo.get(objConstants.CLM_BE_CODE);

		if (rowid != null && beCode != null) {
			if (!objBE.BECode.trim().isEmpty() && !beCode.equals(objBE.BECode)) {
				errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckBECodeCannotChange-00001", objConstants.BE_ERROR_FIELD,
						objConstants.BE_ERROR_OBJECT + " Code cannot change."));
			}
		}

		return errorList;
	}

	public List<ValidationError> CheckLocalLanguageLangIDCannotChange() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckLocalLanguageLangIDCannotChange");

		List<ValidationError> errorList = new ArrayList<>();

		List<DataObject> lstLocalLang = inputSdo.getList(objConstants.SBJ_BE_LOCAL_LANGUAGE);

		if (lstLocalLang != null && !lstLocalLang.isEmpty()) {
			for (DataObject localLang : lstLocalLang) {

				Object localLangRowid = localLang.get(objConstants.CLM_BE_LL_ROWID);
				Object localLangFkId = localLang.get(objConstants.CLM_BE_LL_FK_ROWID);

				if (localLangRowid != null && localLangFkId != null) {
					String strLocalLangFkId = localLangFkId.toString().trim();
					String localLanguageLangIDFromRowID = objBE.GetLocalLanguageLangIDFromRowID(localLangRowid.toString());

					if (!strLocalLangFkId.equals(localLanguageLangIDFromRowID)) {
						errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckLocalLanguageLangIDCannotChange-00001", objConstants.BE_ERROR_FIELD, "Local Language value cannot change."));
					}
				}
			}
		}

		return errorList;
	}

	public List<ValidationError> CheckTargetSystemSysIdCannotChange() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckTargetSystemSysIdCannotChange");

		List<ValidationError> errorList = new ArrayList<>();

		List<DataObject> lstTargSys = inputSdo.getList(objConstants.SBJ_BE_TARGET_SYSTEM);

		if (lstTargSys != null && !lstTargSys.isEmpty()) {
			for (DataObject localLang : lstTargSys) {

				Object targSysRowid = localLang.get(objConstants.CLM_BE_TS_ROWID);
				Object targSysFkId = localLang.get(objConstants.CLM_BE_TS_FK_ROWID);

				if (targSysRowid != null && targSysFkId != null) {
					String strTargSysFkId = targSysFkId.toString().trim();
					String targetSystemSysIdFromRowID = objBE.GetTargetSystemSysIdFromRowID(targSysRowid.toString());

					if (!strTargSysFkId.equals(targetSystemSysIdFromRowID)) {
						errorList.add(
								ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckTargetSystemSysIdCannotChange-00001", objConstants.BE_ERROR_FIELD, "Cross Reference System value cannot change."));
					}
				}
			}
		}

		return errorList;
	}

	// Check for pending changes
	//
	//
	public List<ValidationError> CheckPendingChanges(Map<String, Object> inParams) {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckPendingChanges");

		boolean hasChanges = false;
		List<ValidationError> errorList = new ArrayList<>();

		Object objRecordState = inParams.get("recordState");

		boolean gblRecPending;

		if (objRecordState == null) {
			gblRecPending = false;
		} else {
			String strRecordState = objRecordState.toString();
			if (strRecordState.equalsIgnoreCase("PENDING")) {
				gblRecPending = true;
			} else {
				gblRecPending = false;
			}
		}

		// recordState of pending means they came from the task manager screen so do not check for pending record
		if (!gblRecPending) {

			if (objBE.BEHubState.equals("0")) {
				hasChanges = true;
			}

			if (!hasChanges) {
				for (BETargetSystemGeneric lstTargetSys : objBE.lstBETargetSystem) {
					if (lstTargetSys.hubState.equals("0")) {
						hasChanges = true;
						break;
					}
				}
			}

			if (!hasChanges) {
				for (BELocalLanguageGeneric lstLocLang : objBE.lstBELocalLanguage) {
					if (lstLocLang.hubState.equals("0")) {
						hasChanges = true;
						break;
					}
				}
			}

			if (hasChanges) {
				errorList.add(
						ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckTargetSystemSysIdCannotChange-00001", objConstants.BE_ERROR_FIELD, "This record has a pending change already in process."));
			}
		}

		return errorList;
	}
}
