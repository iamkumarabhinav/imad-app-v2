package com.informatica.mdm.sample.cs;

public class BEConstants {

	public String BE_CLASS_NAME = "";
	public String BE_ERROR_OBJECT = "";
	public String BE_ERROR_FIELD = "";
	public String BE_DATA_SET = "";

	// BE
	public String CLM_BE_ROWID = "";
	public String CLM_BE_CODE = "";
	public int CLM_BE_CODE_MIN_LENGTH = 1;
	public int CLM_BE_CODE_MAX_LENGTH = 20;
	public String CLM_BE_DESC = "";
	public String CLM_BE_ACT_DATE = "";
	public String CLM_BE_INACT_DATE = "";
	
	// Added for Address Code
	public String CLM_BE_ACTIVE = "";
	public String CLM_BE_SITE = "";
	public String CLM_BE_FACILITY = "";
	public String CLM_BE_SUPPLEMENTAL = "";
	public String SBJ_BE_ADDRESS_CODE_MNA = "";
	public String CLM_BE_MNA_ROWID = "";
	public String CLM_BE_MNA_ORGID = "";
	public String CLM_BE_MNA_ADDRESS_CODE = "";
	public String CLM_BE_CUP_FK = "";
	
	
	
	
	
	
	// BE Local Language
	public String SBJ_BE_LOCAL_LANGUAGE = "";
	public String CLM_BE_LL_ROWID = "";
	public String CLM_BE_LL_LANG = ""; // lookup Field Name
	public String CLM_BE_LL_FK_ROWID = ""; // lookup Field Name/refEntity's field name
	public String CLM_BE_LL_FK_CODE = ""; // lookup Field Name/refEntity's field name
	public String CLM_BE_LL_FK_DESC = ""; // lookup Field Name/refEntity's field name
	public String CLM_BE_LL_DESC = "";
	public String CLM_BE_LL_ACT = "";

	// BE Cross Reference System
	public String SBJ_BE_TARGET_SYSTEM = "";
	public String CLM_BE_TS_ROWID = "";
	public String CLM_BE_TS_TARG_SYS = ""; // lookup Field Name
	public String CLM_BE_TS_FK_ROWID = ""; // lookup Field Name/refEntity's field name
	public String CLM_BE_TS_FK_CODE = ""; // lookup Field Name/refEntity's field name
	public String CLM_BE_TS_FK_DESC = ""; // lookup Field Name/refEntity's field name
	public String CLM_BE_TS_REC_CODE = "";
	public String CLM_BE_TS_REC_ID = "";
	public String CLM_BE_TS_ACT = "";

}
