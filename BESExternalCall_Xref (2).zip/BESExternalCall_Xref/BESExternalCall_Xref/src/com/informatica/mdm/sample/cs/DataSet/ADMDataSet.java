package com.informatica.mdm.sample.cs.DataSet;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.log4j.Logger;

import com.informatica.mdm.sample.cs.ADMCommon;
import com.informatica.mdm.sample.cs.ADMError;
import com.informatica.mdm.sdo.cs.base.ValidationError;

import commonj.sdo.DataObject;
import commonj.sdo.helper.HelperContext;

//this is everything Data Set section related
public class ADMDataSet {

	private final static Logger LOGGER = Logger.getLogger(ADMDataSet.class);
	private HelperContext helperContext;
	private DataObject inputSdo;
	private DataSetConstants objConstants;
	private DataSet objBE;

	public ADMDataSet(HelperContext parmHelperContext, DataObject parmInputSdo, DataSetConstants parmConstants, DataSet parmBE) {
		helperContext = parmHelperContext;
		inputSdo = parmInputSdo;
		objConstants = parmConstants;
		objBE = parmBE;
	}

	// Length validations
	//
	//
	public List<ValidationError> CheckLength(String strValue, String strErrorFieldName) {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckBECodeLength");

		List<ValidationError> errorList = new ArrayList<>();

		if (ADMCommon.CheckLength(inputSdo.get(strValue), objConstants.CLM_BE_CODE_MIN_LENGTH, objConstants.CLM_BE_CODE_MAX_LENGTH)) {
			if (objConstants.CLM_BE_CODE_MIN_LENGTH == objConstants.CLM_BE_CODE_MAX_LENGTH) {
				errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckBECodeLength-00001", objConstants.BE_ERROR_FIELD,
						objConstants.BE_ERROR_OBJECT + " " + strErrorFieldName + " must be " + objConstants.CLM_BE_CODE_MIN_LENGTH + " characters long."));
			} else {
				errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckBECodeLength-00002", objConstants.BE_ERROR_FIELD, objConstants.BE_ERROR_OBJECT + " "
						+ strErrorFieldName + " must be between " + objConstants.CLM_BE_CODE_MIN_LENGTH + " and " + objConstants.CLM_BE_CODE_MAX_LENGTH + " characters long."));
			}
		}

		return errorList;
	}

	// Noisy Char validations
	//
	//
	public List<ValidationError> CheckNoisyChar(String strValue, String strErrorFieldName) {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckBENoisyChar");

		List<ValidationError> errorList = new ArrayList<>();
		Object strFoundValue = inputSdo.get(strValue.toString());

		// check BE Code noisy char
		if (strFoundValue != null) {
			if (ADMCommon.CheckNoisyChar(strFoundValue.toString())) {
				errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckBENoisyChar-00001", objConstants.BE_ERROR_FIELD,
						objConstants.BE_ERROR_OBJECT + " " + strErrorFieldName + " is not valid. "));
			}
		}

		return errorList;
	}

	public List<ValidationError> CheckSpaceChar(String strValue, String strErrorFieldName) {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckBENoisyChar");

		List<ValidationError> errorList = new ArrayList<>();
		Object strFoundValue = inputSdo.get(strValue);

		// check BE Code space char
		if (strFoundValue != null) {
			if (ADMCommon.CheckSpaceChar(strFoundValue.toString())) {
				errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckBENoisyChar-00002", objConstants.BE_ERROR_FIELD,
						objConstants.BE_ERROR_OBJECT + " " + strErrorFieldName + " cannot contain spaces."));
			}
		}

		return errorList;
	}

	// Email Format validations
	//
	//
	public List<ValidationError> ChecBEEmailFormat() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " ChecBEEmailFormat");

		List<ValidationError> errorList = new ArrayList<>();

		Object objEmail = inputSdo.get(objConstants.CLM_BE_EMAIL);
		String strEmail = "";

		if (objEmail != null) {
			strEmail = objEmail.toString();

			if (!ADMCommon.isValidEmail(strEmail)) {
				errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".ChecBEEmailFormat-00001", objConstants.BE_ERROR_FIELD,
						objConstants.BE_ERROR_OBJECT + " Email Notification " + " " + strEmail + " is not valid."));
			}
		}

		return errorList;
	}

	public List<ValidationError> CheckTargetSystemEmailFormat() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckTargetSystemEmailFormat");

		List<ValidationError> errorList = new ArrayList<>();

		List<DataObject> lstLocalLang = inputSdo.getList(objConstants.SBJ_BE_TARGET_SYSTEM);

		if (lstLocalLang != null && !lstLocalLang.isEmpty()) {
			for (DataObject localLang : lstLocalLang) {

				Object objEmail = localLang.get(objConstants.CLM_BE_TS_EMAIL);
				String strEmail = "";

				if (objEmail != null) {
					strEmail = objEmail.toString();

					if (!ADMCommon.isValidEmail(strEmail)) {
						errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckTargetSystemEmailFormat-00001", objConstants.BE_ERROR_FIELD,
								objConstants.BE_ERROR_OBJECT + " Cross Reference System Email Notification " + " " + strEmail + " is not valid."));
					}
				}
			}
		}

		return errorList;
	}

	// Duplicate validations
	//
	//
	public List<ValidationError> CheckBEDup() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckBEDup");

		List<ValidationError> errorList = new ArrayList<>();

		Object objRowid = inputSdo.get(objConstants.CLM_BE_ROWID);
		Object objCode = inputSdo.get(objConstants.CLM_BE_CODE);
		if (objRowid == null && objCode != null) {
			String strCode = objCode.toString();

			try {
				if (objBE.BECodeFound) {
					errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckBEDup-00002", objConstants.BE_ERROR_FIELD,
							objConstants.BE_ERROR_OBJECT + " " + strCode + " is duplicated."));
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.info(e.getMessage());
			}
		}

		return errorList;
	}

	public List<ValidationError> CheckApprovalRoleDup() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckApprovalRoleDup");

		List<ValidationError> errorList = new ArrayList<>();
		List<String> lstApprRole = new ArrayList<String>();
		lstApprRole.clear();

		if (objBE.lstBEApprover != null) {
			try {
				for (DataSetApprover apprRole : objBE.lstBEApprover) {
					lstApprRole.add(apprRole.AddressCode);
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.info(e.getMessage());
			}
		}

		List<DataObject> listApprover = inputSdo.getList(objConstants.SBJ_BE_APPROVER);
		if (listApprover != null && !listApprover.isEmpty()) {
			for (DataObject lstApprover : listApprover) {
				Object objApproverRowid = lstApprover.get(objConstants.CLM_BE_AP_ROWID);
				Object objApproverFKRowid = lstApprover.get(objConstants.CLM_BE_AP_ROLE_FK_ROWID);
				Object objApproverFKRole = lstApprover.get(objConstants.CLM_BE_AP_ROLE_FK_ROLE);
				String strApproverFKRowid = "";
				String strApproverFKRole = "";

				if (objApproverFKRowid != null) {
					strApproverFKRowid = objApproverFKRowid.toString().trim();
				}
				if (objApproverFKRole != null) {
					strApproverFKRole = objApproverFKRole.toString().trim();
				}
				// NEW ONE
				if (objApproverRowid == null && !strApproverFKRole.isEmpty()) {
					if (lstApprRole.contains(strApproverFKRowid)) {
						errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckApprovalRoleDup-00001", objConstants.BE_ERROR_FIELD,
								"Approver Role " + strApproverFKRole + " is duplicated."));
					} else {
						lstApprRole.add(strApproverFKRowid);
					}
				}
			}
		}

		return errorList;
	}

	public List<ValidationError> CheckApprovalOrderValue(int minValue) {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckApprovalOrderValue");

		List<ValidationError> errorList = new ArrayList<>();
		List<String> lstApprRole = new ArrayList<String>();
		lstApprRole.clear();

		List<DataObject> listApprover = inputSdo.getList(objConstants.SBJ_BE_APPROVER);
		if (listApprover != null && !listApprover.isEmpty()) {
			for (DataObject lstApprover : listApprover) {
				int objApproverOrder = lstApprover.getInt(objConstants.CLM_BE_AP_APPR_ORD);

				// NEW ONE
				if (objApproverOrder < objConstants.CLM_BE_AP_APPR_ORD_MIN) {
					errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckApprovalRoleDup-00001", objConstants.BE_ERROR_FIELD,
							"Approver Order must be " + objConstants.CLM_BE_AP_APPR_ORD_MIN + " or greater."));
				}
			}
		}

		return errorList;
	}

	public List<ValidationError> CheckApprovalOrderDup() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckApprovalOrderDup");

		List<ValidationError> errorList = new ArrayList<>();
		ArrayList<ArrayList<String>> aryApprover = new ArrayList<ArrayList<String>>();
		ArrayList<String> aryOrderValues = new ArrayList<>();
		ArrayList<String> aryDuplicates = new ArrayList<>();

		// records from screen
		List<DataObject> listChanges = inputSdo.getList(objConstants.SBJ_BE_APPROVER);
		if (listChanges != null && !listChanges.isEmpty()) {
			for (DataObject lstApprover : listChanges) {
				Object objApproverRowid = lstApprover.get(objConstants.CLM_BE_AP_ROWID);
				Object objApproverOrder = lstApprover.get(objConstants.CLM_BE_AP_APPR_ORD);

				ArrayList<String> toAdd = new ArrayList<>();
				toAdd.add(ADMCommon.CheckforNull(objApproverRowid));
				toAdd.add(objApproverOrder.toString().trim());

				aryApprover.add(toAdd);
			}
		}

		// add existing to list, if not in the records from screen
		if (objBE.lstBEApprover != null) {
			try {
				for (DataSetApprover apprRole : objBE.lstBEApprover) {
					String rowid = apprRole.rowID.trim();
					String order = apprRole.approvalOrder.trim();

					boolean rowFound = false;
					for (ArrayList<String> appr : aryApprover) {
						if (appr.get(0).equals(rowid)) {
							rowFound = true;
							break;
						}
					}
					if (!rowFound) {
						ArrayList<String> toAdd = new ArrayList<>();
						toAdd.add(rowid);
						toAdd.add(order);

						aryApprover.add(toAdd);
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.info(e.getMessage());
			}
		}

		for (ArrayList<String> appr : aryApprover) {
			String orderValue = appr.get(1);

			if (!aryOrderValues.contains(orderValue)) {
				aryOrderValues.add(orderValue);
			} else if (!aryDuplicates.contains(orderValue)) {
				aryDuplicates.add(orderValue);
			}
		}

		for (String apOrder : aryDuplicates) {
			errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckApprovalOrderDup-00001", objConstants.BE_ERROR_FIELD,
					"Approver Order " + apOrder + " is duplicated."));
		}

		return errorList;
	}

	public List<ValidationError> CheckTargetSystemDup() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckTargetSystemDup");

		List<ValidationError> errorList = new ArrayList<>();
		List<String> lstSysCode = new ArrayList<String>();
		lstSysCode.clear();

		if (objBE.lstBETargetSystem != null) {
			try {
				for (DataSetTargetSystem targSys : objBE.lstBETargetSystem) {
					lstSysCode.add(targSys.targetSysCode);
				}
			} catch (Exception e) {
				e.printStackTrace();
				LOGGER.info(e.getMessage());
			}
		}

		List<DataObject> listTargetSys = inputSdo.getList(objConstants.SBJ_BE_TARGET_SYSTEM);
		if (listTargetSys != null && !listTargetSys.isEmpty()) {
			for (DataObject lstTargetSys : listTargetSys) {
				Object objTargetSysRowid = lstTargetSys.get(objConstants.CLM_BE_TS_ROWID);
				Object objTargetSysCode = lstTargetSys.get(objConstants.CLM_BE_TS_FK_CODE);
				String strTargetSysCode = "";

				if (objTargetSysCode != null) {
					strTargetSysCode = objTargetSysCode.toString().trim();
				}
				// NEW ONE
				if (objTargetSysRowid == null && !strTargetSysCode.isEmpty()) {
					if (lstSysCode.contains(strTargetSysCode)) {
						errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckTargetSystemDup-00001", objConstants.BE_ERROR_FIELD,
								"Cross Reference System " + strTargetSysCode + " is duplicated."));
					} else {
						lstSysCode.add(strTargetSysCode);
					}
				}
			}
		}

		return errorList;
	}

	// Cannot change identifying field value
	//
	//
	public List<ValidationError> CheckBECodeCannotChange() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckBECodeCannotChange");

		List<ValidationError> errorList = new ArrayList<>();

		Object rowid = inputSdo.get(objConstants.CLM_BE_ROWID);
		Object beCode = inputSdo.get(objConstants.CLM_BE_CODE);

		if (rowid != null && beCode != null) {
			if (!objBE.BEDataSetCode.trim().isEmpty() && !beCode.equals(objBE.BEDataSetCode)) {
				errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckBECodeCannotChange-00001", objConstants.BE_ERROR_FIELD,
						objConstants.BE_ERROR_OBJECT + " Code cannot change."));
			}
		}

		return errorList;
	}

	public List<ValidationError> CheckAddressCodeCannotChange() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckAddressCodeCannotChange");

		List<ValidationError> errorList = new ArrayList<>();

		List<DataObject> lstApprover = inputSdo.getList(objConstants.SBJ_BE_APPROVER);

		if (lstApprover != null && !lstApprover.isEmpty()) {
			for (DataObject approver : lstApprover) {

				Object approverRowid = approver.get(objConstants.CLM_BE_AP_ROWID);
				Object approvalRole = approver.get(objConstants.CLM_BE_AP_ROLE_FK_ROWID);

				if (approverRowid != null && approvalRole != null) {
					if (!approvalRole.equals(objBE.GetRoleNameFromRowID(approverRowid.toString()))) {
						errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckAddressCodeCannotChange-00001", objConstants.BE_ERROR_FIELD, "Approver Role value cannot change."));
					}
				}
			}
		}

		return errorList;
	}

	public List<ValidationError> CheckTargetSystemSysIdCannotChange() {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckTargetSystemSysIdCannotChange");

		List<ValidationError> errorList = new ArrayList<>();

		List<DataObject> lstLocalLang = inputSdo.getList(objConstants.SBJ_BE_TARGET_SYSTEM);

		if (lstLocalLang != null && !lstLocalLang.isEmpty()) {
			for (DataObject localLang : lstLocalLang) {

				Object targSysRowid = localLang.get(objConstants.CLM_BE_TS_ROWID);
				Object targSys = localLang.get(objConstants.CLM_BE_TS_FK_ROWID);

				if (targSysRowid != null && targSys != null) {
					if (!targSys.equals(objBE.GetTargetSystemSysIdFromRowID(targSysRowid.toString()))) {
						errorList.add(ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckTargetSystemSysIdCannotChange-00001", objConstants.BE_ERROR_FIELD, "Cross Reference System value cannot change."));
					}
				}
			}
		}

		return errorList;
	}

	// Check for pending changes
	//
	//
	public List<ValidationError> CheckPendingChanges(Map<String, Object> inParams) {

		LOGGER.info("In Start " + objConstants.BE_CLASS_NAME + " CheckPendingChanges");

		boolean hasChanges = false;
		List<ValidationError> errorList = new ArrayList<>();

		Object objRecordState = inParams.get("recordState");
		boolean gblRecPending;
		if (objRecordState == null) {
			gblRecPending = false;
		} else {
			String strRecordState = objRecordState.toString();
			if (strRecordState.equalsIgnoreCase("PENDING")) {
				gblRecPending = true;
			} else {
				gblRecPending = false;
			}
		}

		// recordState of pending means they came from the task manager screen so do not check for pending record
		if (!gblRecPending) {
			if (objBE.BEHubState.equals("0")) {
				hasChanges = true;
			}

			if (!hasChanges) {
				for (DataSetTargetSystem lstTargetSys : objBE.lstBETargetSystem) {
					if (lstTargetSys.hubState.equals("0")) {
						hasChanges = true;
						break;
					}
				}
			}

			if (!hasChanges) {
				for (DataSetApprover lstTargetSys : objBE.lstBEApprover) {
					if (lstTargetSys.hubState.equals("0")) {
						hasChanges = true;
						break;
					}
				}
			}

			if (hasChanges) {
				errorList.add(
						ADMError.SetValicationError(helperContext, objConstants.BE_CLASS_NAME + ".CheckTargetSystemSysIdCannotChange-00001", objConstants.BE_ERROR_FIELD, "This record has a pending change already in process."));
			}
		}

		return errorList;
	}
}