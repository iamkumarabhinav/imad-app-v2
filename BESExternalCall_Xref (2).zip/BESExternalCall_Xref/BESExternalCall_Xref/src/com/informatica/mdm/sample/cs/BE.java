package com.informatica.mdm.sample.cs;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import org.apache.log4j.Logger;

import com.informatica.mdm.sample.cs.BELocalLanguageGeneric;
import com.informatica.mdm.sample.cs.BETargetSystemGeneric;
import com.informatica.mdm.sample.cs.DataSet.DataSet;

// if there is a pending record it will get the pending state
public class BE {
	String RowId = "";
	String BECode = "";
	String BEDesc = "";
	Date BEActiveDate = null;
	Date BEInactiveDate = null;
	String BEHubState = "";
	Boolean BECodeFound = false;
	DataSet BEDataSet = null;

	List<BETargetSystemGeneric> lstBETargetSystem = new ArrayList<BETargetSystemGeneric>();
	List<BELocalLanguageGeneric> lstBELocalLanguage = new ArrayList<BELocalLanguageGeneric>();

	private static final Logger LOGGER = Logger.getLogger(BE.class);

	public BE(String parmRowId, String parmBECode, String parmBEDesc, Date parmActiveDate, Date parmInactiveDate, String parmBEHubState, Boolean parmBECodeFound, List<BETargetSystemGeneric> parmLstBETargetSystem,
			List<BELocalLanguageGeneric> parmLstBELocalLanguage, DataSet parmDataSet) {
		try {
			RowId = parmRowId;
			BECode = parmBECode;
			BEDesc = parmBEDesc;
			BEActiveDate = parmActiveDate;
			BEInactiveDate = parmInactiveDate;
			BEHubState = parmBEHubState;
			BECodeFound = parmBECodeFound;

			lstBETargetSystem = parmLstBETargetSystem;
			lstBELocalLanguage = parmLstBELocalLanguage;
			
			BEDataSet = parmDataSet;
		} catch (Exception e) {
			e.printStackTrace();
			LOGGER.info(e.getMessage());
		}
	}

	public String GetTargetSystemSysIdFromRowID(String RowID) {
		for (BETargetSystemGeneric targSys : lstBETargetSystem) {
			if (targSys.rowID.equalsIgnoreCase(RowID.trim())) {
				return targSys.targetSysCode;
			}
		}
		return "";
	}

	public String GetLocalLanguageLangIDFromRowID(String RowID) {
		for (BELocalLanguageGeneric locLang : lstBELocalLanguage) {
			if (locLang.rowID.equalsIgnoreCase(RowID.trim())) {
				return locLang.langId;
			}
		}
		return "";
	}
}
