package com.informatica.mdm.sample.cs;

import java.util.regex.Pattern;

public class ADMCommon {

	// true means the field failed
	public static boolean CheckLength(Object objField, int intMinLength, int intMaxLength) {

		if (objField != null) {
			return objField.toString().length() < intMinLength // too short
					|| objField.toString().length() > intMaxLength; // too long
		} else
			return false;
	}

	// true means the field failed
	public static boolean CheckSpaceChar(String strField) {

		return strField.contains(" ");
	}

	// true means the field failed
	public static boolean CheckNoisyChar(String strField) {

		return strField.matches(".*[%$@*!?<>].*");
	}

	// true means the field passes
	public static boolean isValidEmail(String strField) {
		String emailExpr = "^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,20}$";

		Pattern pat = Pattern.compile(emailExpr);
		if (strField == null)
			return false;
		return pat.matcher(strField).matches();
	}

	// true means the field failed
	public static boolean CheckOnlyNumber_Plus_Minus(String strField) {

		return !strField.matches("^[0-9]*$");
	}

	// true means the field failed
	public static boolean CheckContainAttentionLine(String strField) {

		return strField.matches("(DBA |ATTENTION TO|C\\/O)");
	}

	// true means the field failed
	public static boolean CheckEmpty(Object strField) {

		if (strField == null) {
			return true;
		}

		if (strField.toString().trim().isEmpty()) {
			return true;
		}

		return false;
	}

	public static String CheckforNull(Object objField) {
		if (objField != null) {
			return objField.toString().trim();
		} else {
			return "";
		}
	}

}
