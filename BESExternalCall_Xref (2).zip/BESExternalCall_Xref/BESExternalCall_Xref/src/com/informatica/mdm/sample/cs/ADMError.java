package com.informatica.mdm.sample.cs;

import java.util.Collections;

import com.informatica.mdm.sdo.cs.base.ValidationError;

import commonj.sdo.helper.DataFactory;
import commonj.sdo.helper.HelperContext;

public class ADMError {

	public static ValidationError SetValicationError(HelperContext helperContext, String strCode, String strFields, String strMessage) {

		DataFactory dataFactory = helperContext.getDataFactory();

		ValidationError error = (ValidationError) dataFactory.create(ValidationError.class);
		error.setCode(strCode);
		error.setField(Collections.singletonList(strFields));

		error.setMessage(strMessage);

		return error;

	}
}
