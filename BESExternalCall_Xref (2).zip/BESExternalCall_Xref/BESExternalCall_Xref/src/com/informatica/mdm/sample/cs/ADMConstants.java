package com.informatica.mdm.sample.cs;

public class ADMConstants {

	// Data Source
	public static final String DATA_SOURCE = "jdbc/xref_ors-ds";

}
