package com.informatica.mdm.sample.cs.DataSet;

public class DataSetTargetSystem {

	public String rowID = "";
	public String dataSetCode = "";
	public String targetSysCode = "";
	public String requiredSystem = "";
	public String crossReferenceManualEntry = "";
	public String emailNotification = "";
	public String actInd = "";
	public String hubState = "";

	public DataSetTargetSystem(String RowID, String DataSetCode, String TargetSysCode, String RequiredSystem, String CrossReferenceManualEntry, String EmailNotification, String ActInd, String HubState) {

		rowID = RowID.trim();
		dataSetCode = DataSetCode.trim();
		targetSysCode = TargetSysCode.trim();
		requiredSystem = RequiredSystem.trim();
		crossReferenceManualEntry = CrossReferenceManualEntry.trim();
		emailNotification = EmailNotification.trim();
		actInd = ActInd.trim();
		hubState = HubState.trim();
	}
}
