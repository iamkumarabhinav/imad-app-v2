package com.springdemo.dao;
import java.util.List;
import com.springdemo.entity.Question;

public interface QuestionDAO {
	
	public List<Question> getQuestions(String cname, int iid);

	public void saveQuestion(Question theQuestion);

	public void updateQuestion(Question theQuestion);

	public void deleteQuestion(int qno, String cname, int cd);

	public Question getQuestion(int qno, String cid, int iid);

	public int[] validateTestId(String testId);

	public List<Question> getStudQuestions(int i, int j);

}
