package com.springdemo.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import org.springframework.stereotype.Repository;

import com.springdemo.entity.User;

@Repository
public class UserDAOImpl implements UserDAO {
	
	private Connection connection;
    private CallableStatement cst=null;
    private PreparedStatement pst=null;
    private ResultSet rst=null;
    Statement stmt = null;
	
	public UserDAOImpl() {
		connection = DBUtil.getConnection();
        if(connection!=null)
                        System.out.println("connection done");
        else
                        System.out.println("not done");
	}

	@Override
	public int verifyUser(User theUser) {
		String uname=null;
		String p=null;
		String role=null;
		int x=0;
		try {
			pst = connection.prepareStatement("select * from usert80 WHERE email=? AND PWD=?" );
			pst.setString(1,theUser.getEmail());
			pst.setString(2,theUser.getPwd());
			rst=pst.executeQuery();
			if(rst.next())
			{
        		uname=rst.getString(3);
        		p=rst.getString(4);
        		role=rst.getString(5);
        		x=rst.getInt(1);
			}
        }catch (SQLException e) {
        	System.out.println("Exception in verifyUser");
		}
		if(p==null)
			return 0;
		else if(p.equals(theUser.getPwd())&& uname.equals(theUser.getEmail()))
		{
			if(role.equals("teacher"))
				return x*10+2;
			else 
				return x*10+1;
		}
		else
		return 0;
		// TODO Auto-generated method stub
		
	}

	@Override
	public boolean addUser(User theUser) {
		// TODO Auto-generated method stub
		try {
            cst = connection.prepareCall("call INSERT_Usert80(?,?,?,?,?,?)");
            cst.setInt(1,theUser.getRoll());
            cst.setString(2,theUser.getStudName());
            cst.setString(4,theUser.getPwd());
            cst.setString(5,theUser.getUserRole());
            cst.setString(3,theUser.getEmail());
            cst.setString(6,theUser.getMobile());
            cst.execute();
     } catch (SQLException e) {
    	 System.out.println("Exception in addUser");
     }
        try {
			stmt = connection.createStatement();
		} catch (SQLException e) {
			System.out.println("Exception in addUser1");
		}
        try {
			rst=stmt.executeQuery("commit;");
		} catch (SQLException e) {
			System.out.println("Exception in addUser2");
		}
        User s=getUser(theUser.getRoll());
        if(s.getRoll()==theUser.getRoll())
        {
        	return true;
        }
        else 
        	return false;
	}

	@Override
	public User getUser(int roll) {
		// TODO Auto-generated method stub
		User s=new User();
		try {
			pst = connection.prepareStatement("select * from Usert80 WHERE userid=?");
			pst.setInt(1,roll);
			rst=pst.executeQuery();
		
        	if(rst.next())
			{
				s.setRoll(rst.getInt(1));
				s.setEmail(rst.getString(3));
				s.setMobile(rst.getString(6));
				s.setStudName(rst.getString(2));
				s.setPwd(rst.getString(4));
				s.setUserRole(rst.getString(5));
			} 
        	
        }catch (SQLException e) {
			// TODO Auto-generated catch block
        	System.out.println("Exception in getUser");
		}
		
		
		return s;
	}

}
