package com.springdemo.dao;

import java.util.List;

import com.springdemo.entity.Course;

public interface CourseDAO {

	public List<Course> getAllCourse(int i);

	public boolean checkNewTeacher(int roll);

	public void enrollTeacher(int cid, int iid);

	public List<Course> getAbleCourse(int roll);

	public void generateTestId(String cname, int iid, String testId);

}
