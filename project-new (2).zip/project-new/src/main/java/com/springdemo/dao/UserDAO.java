package com.springdemo.dao;

import com.springdemo.entity.User;

public interface UserDAO {

	int verifyUser(User theUser);

	boolean addUser(User theUser);
	
	public User getUser(int roll);

}
