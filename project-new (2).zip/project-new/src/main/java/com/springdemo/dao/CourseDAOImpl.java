package com.springdemo.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.stereotype.Repository;

import com.springdemo.entity.Course;

@Repository
public class CourseDAOImpl implements CourseDAO {

	private Connection connection;
    private CallableStatement cst=null;
    private PreparedStatement pst=null;
    private ResultSet rst=null;
    Statement stmt = null;


	public CourseDAOImpl() {
		
		connection = DBUtil.getConnection();
        if(connection!=null)
                        System.out.println("connection done");
        else
                        System.out.println("not done");
	}


	@Override
	public List<Course> getAllCourse(int i) {
		// TODO Auto-generated method stub
		List<Course> CSet=new ArrayList<Course>();
		try {//select c.cid,c.cname,c.cduration from courset80 join enrolli80 on 
			pst = connection.prepareStatement("select * from courset80 where cid not in(select cid from enrolli80 where userid=?) order by cid");
			pst.setInt(1,i);
			rst=pst.executeQuery();
			while(rst.next())
			{
				int cid=rst.getInt(1);
				String cname=rst.getString(2);
				int cdur=rst.getInt(3);
				Course c=new Course(cid,cname,cdur);
				CSet.add(c);
			}
        }catch (SQLException e) {
			System.out.println("Exception in getAllCourse");  e.printStackTrace();
		}
		return CSet;
	}


	@Override
	public boolean checkNewTeacher(int roll) {
		int x=0;
		try {
			pst = connection.prepareStatement("select cid from enrolli80 where userid=? order by cid");
			pst.setInt(1,roll);
			rst=pst.executeQuery();
			while(rst.next())
			{
				x=rst.getInt(1);
			}
        }catch (SQLException e) {
        	System.out.println("Exception in checkNewTeacher");  e.printStackTrace();
		}
		if(x==0)
		return true;
		else
			return false;
	}
	
	
	



	@Override
	public void enrollTeacher(int cid, int iid) {
		try {
			pst = connection.prepareStatement("INSERT INTO enrollI80 (userId,cid,studnum,joindate) VALUES (?,?,?,?)");
			pst.setInt(1,iid);
			pst.setInt(2,cid);
			pst.setInt(3,0);
			Date date=new Date();
			pst.setString(4,date.toString());
			rst=pst.executeQuery();
        }catch (SQLException e) {
        	System.out.println("Exception in enrollTeacher");  e.printStackTrace();
		}
		
	}


	@Override
	public List<Course> getAbleCourse(int roll) {
		// TODO Auto-generated method stub
		List<Course> CSet=new ArrayList<Course>();
		try {
			pst = connection.prepareStatement("select * from courset80 where cid in(select cid from enrolli80 where userid=?) order by cid");
			pst.setInt(1,roll);
			rst=pst.executeQuery();
			while(rst.next())
			{
				int cid=rst.getInt(1);
				String cname=rst.getString(2);
				int cdur=rst.getInt(3);
				Course c=new Course(cid,cname,cdur);
				CSet.add(c);
			}
        }catch (SQLException e) {
        	System.out.println("Exception in getAbleCourse");  e.printStackTrace();
		}
		return CSet;
	}



	@Override
	public void generateTestId(String cname, int iid,String testId) {
		// TODO Auto-generated method stub
		try {
            cst = connection.prepareCall("call GenerateTestId(?,?,?)");
            cst.setInt(1,iid);
            cst.setString(2,cname);
            cst.setString(3,testId);
            cst.execute();
     } catch (SQLException e) {
            e.printStackTrace();
     }
        try {
			stmt = connection.createStatement();
		} catch (SQLException e) {
			System.out.println("Exception in GenerateTestId");  e.printStackTrace();
		}
        try {
			rst=stmt.executeQuery("commit");
		} catch (SQLException e) {
			
			// TODO Auto-generated catch block
			System.out.println("Exception in commit GenerateTestId");  e.printStackTrace();
		}
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
}
