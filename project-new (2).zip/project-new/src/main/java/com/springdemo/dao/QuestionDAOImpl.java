package com.springdemo.dao;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.springdemo.entity.Course;
import com.springdemo.entity.Question;
import com.springdemo.util.QuestionRowMapper;

@Repository
public class QuestionDAOImpl implements QuestionDAO {

	private Connection connection;
    private CallableStatement cst=null;
    private PreparedStatement pst=null;
    private ResultSet rst=null;
    Statement stmt = null;

    @Autowired
	private JdbcTemplate template;


	

	public JdbcTemplate getTemplate() {
		return template;
	}

	public void setTemplate(JdbcTemplate template) {
		this.template = template;
	}
	
	public QuestionDAOImpl() {
		
		connection = DBUtil.getConnection();
        if(connection!=null)
                        System.out.println("connection done");
        else
                        System.out.println("not done");

	}

	
	public QuestionDAOImpl(JdbcTemplate template) {
		super();
		this.template = template;
		connection = DBUtil.getConnection();
        if(connection!=null)
                        System.out.println("connection done");
        else
                        System.out.println("not done");
		
		
	}
	
	@Override
	public List<Question> getQuestions(String cname, int iid) {
		// TODO Auto-generated method stub
		List<Question> QSet=new ArrayList<Question>();
		String query="select * from question380 WHERE CNAME= '"+cname+"' AND IID="+iid;
		System.out.println(query);
		QSet=template.query(query,new QuestionRowMapper());
		return QSet;
	}
	
	
	@Override
	public Question getQuestion(int qno,String cname, int iid) {
		Question foundQuestion=null;
		String query="SELECT * FROM question380 WHERE CNAME='"+cname+"' AND QNO="+qno+"AND IID="+iid;
		System.out.println(query);
		foundQuestion=template.queryForObject(query,new QuestionRowMapper());
		return foundQuestion;
	}
	
	@Override
	public List<Question> getStudQuestions(int i, int j) {
		// TODO Auto-generated method stub
		
		List<Question> QSet=new ArrayList<Question>();
		String cname=null;
		try {
			pst = connection.prepareStatement("select cname from courset80 WHERE cid=?" );
			pst.setInt(1,j);
			rst=pst.executeQuery();
			if(rst.next())
			{
        		cname=rst.getString(1);
			}
        }catch (SQLException e) {
        	System.out.println("Exception in getStudQuestion");
		}
		
		String query="select * from question380 WHERE CNAME= '"+cname+"' AND IID="+i;
		System.out.println(query);
		QSet=template.query(query,new QuestionRowMapper());
		return QSet;
		
	}
	
	@Override
	public void saveQuestion(Question theQuestion) {
		// TODO Auto-generated method stub
        try {
            cst = connection.prepareCall("call INSERT_QUESTION380(?,?,?,?,?,?,?,?,?,?)");
            cst.setInt(1,theQuestion.getQuesno());
            cst.setString(2,theQuestion.getQues());
            cst.setString(3,theQuestion.getOpt1());
            cst.setString(4,theQuestion.getOpt2());
            cst.setString(5,theQuestion.getOpt3());
            cst.setString(6,theQuestion.getOpt4());
            cst.setInt(7,theQuestion.getAns());
            cst.setInt(8,theQuestion.getMarks());
            cst.setString(9,theQuestion.getCname());
            cst.setInt(10,theQuestion.getIid());
            cst.execute();
     } catch (SQLException e) {
            e.printStackTrace();
     }
        try {
			stmt = connection.createStatement();
		} catch (SQLException e) {
			System.out.println("Exception in saveQuestion");  e.printStackTrace();
		}
        try {
			rst=stmt.executeQuery("commit;");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception in commit");  e.printStackTrace();
		}

        
	}
	

	



	@Override
	public void updateQuestion(Question theQuestion) {
		// TODO Auto-generated method stub
		 try {
	            cst = connection.prepareCall("call UPDATE_QUESTION380(?,?,?,?,?,?,?,?,?,?)");
	            cst.setInt(1,theQuestion.getQuesno());
	            cst.setString(2,theQuestion.getQues());
	            cst.setString(3,theQuestion.getOpt1());
	            cst.setString(4,theQuestion.getOpt2());
	            cst.setString(5,theQuestion.getOpt3());
	            cst.setString(6,theQuestion.getOpt4());
	            cst.setInt(7,theQuestion.getAns());
	            cst.setInt(8,theQuestion.getMarks());
	            cst.setString(9,theQuestion.getCname());
	            cst.setInt(10,theQuestion.getIid());
	            cst.execute();
	     } catch (SQLException e) {
	    	 System.out.println("Exception in updateQuestion");  e.printStackTrace();
	     }
	        try {
				stmt = connection.createStatement();
			} catch (SQLException e) {
				e.printStackTrace();
			}
	        try {
				rst=stmt.executeQuery("commit;");
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				System.out.println("Exception in commit");  e.printStackTrace();
			}

	}


	@Override
	public void deleteQuestion(int qno, String cname, int iid) {
		
		try {
            cst = connection.prepareCall("call DELETE_QUESTION380(?,?,?)");
            cst.setInt(1,qno);
            cst.setString(2,cname);
            cst.setInt(3,iid);
            cst.execute();
     } catch (SQLException e) {
            e.printStackTrace();
     }
        try {
			stmt = connection.createStatement();
		} catch (SQLException e) {
			System.out.println("Exception in deleteQuestion");  e.printStackTrace();
		}
        try {
			rst=stmt.executeQuery("commit;");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			System.out.println("Exception in commit");  e.printStackTrace();
		}
	}



	




	@Override
	public int[] validateTestId(String testId) {
		// TODO Auto-generated method stub
		int[] x = new int[3];
		x[0]=0;x[1]=0;x[2]=0;
		String tId=null;
		try {
			pst = connection.prepareStatement("select testId from enrolli80 WHERE testId=?" );
			pst.setString(1,testId);
			rst=pst.executeQuery();
			if(rst.next())
			{
        		tId=rst.getString(1);
			}
        }catch (SQLException e) {
        	System.out.println("Exception in verifyUser");
		}
		if(tId==null)
			return x;
		else if(tId.equals(testId))
		{
			x[2]=1;
			try {
				pst = connection.prepareStatement("select UserId,Cid from enrolli80 where testid=?");
				pst.setString(1,testId);
				rst=pst.executeQuery();
				if(rst.next())
				{
					x[0]=rst.getInt(1);
					x[1]=rst.getInt(2);
				}
	        }catch (SQLException e) {
	        	System.out.println("Exception in getAbleCourse");  e.printStackTrace();
			}
			return x;
		}
		else
		return x;
	}


	
}
