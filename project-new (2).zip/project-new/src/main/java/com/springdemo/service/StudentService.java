package com.springdemo.service;

public interface StudentService {

}
