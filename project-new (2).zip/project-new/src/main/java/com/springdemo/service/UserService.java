package com.springdemo.service;

import com.springdemo.entity.User;

public interface UserService {

	int verifyUser(User theUser);

	boolean addUser(User theUser);

	User getUser(int i);

}
