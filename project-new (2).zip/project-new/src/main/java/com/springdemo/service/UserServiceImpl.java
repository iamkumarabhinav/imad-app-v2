package com.springdemo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springdemo.dao.UserDAO;
import com.springdemo.entity.User;

@Service
public class UserServiceImpl implements UserService {

	@Autowired
	private UserDAO userDAO;
	
	@Override
	public int verifyUser(User theStudent) {
		// TODO Auto-generated method stub
			return userDAO.verifyUser(theStudent);
	}

	@Override
	public boolean addUser(User theStudent) {
		// TODO Auto-generated method stub
		return userDAO.addUser(theStudent);
	}

	@Override
	public User getUser(int i) {
		// TODO Auto-generated method stub
		return userDAO.getUser(i);
	}

}
