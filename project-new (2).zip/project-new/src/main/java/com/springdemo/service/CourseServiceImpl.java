package com.springdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springdemo.dao.CourseDAO;
import com.springdemo.entity.Course;

@Service
public class CourseServiceImpl implements CourseService {

	@Autowired
	private CourseDAO courseDAO;

	@Override
	public List<Course> getAllCourse(int i) {
		// TODO Auto-generated method stub
		return courseDAO.getAllCourse(i);
	}

	@Override
	public boolean checkNewTeacher(int roll) {
		// TODO Auto-generated method stub
		return courseDAO.checkNewTeacher(roll);
	}

	@Override
	public void enrollTeacher(int cid, int iid) {
		// TODO Auto-generated method stub
		courseDAO.enrollTeacher(cid,iid);
	}

	@Override
	public List<Course> getAbleCourse(int roll) {
		// TODO Auto-generated method stub
		return courseDAO.getAbleCourse(roll);
	}

	@Override
	public void generateTestId(String cname, int iid, String testId) {
		// TODO Auto-generated method stub
		courseDAO.generateTestId(cname,iid,testId);
	}

}
