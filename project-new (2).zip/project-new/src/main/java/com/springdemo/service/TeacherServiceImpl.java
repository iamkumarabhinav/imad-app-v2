package com.springdemo.service;

import org.springframework.stereotype.Service;

@Service
public class TeacherServiceImpl implements TeacherService {

}
