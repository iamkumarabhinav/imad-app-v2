package com.springdemo.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.springdemo.dao.QuestionDAO;
import com.springdemo.entity.Question;

@Service
public class QuestionServiceImpl implements QuestionService {
	
	@Autowired
	private QuestionDAO questionDAO;

	@Override
	public void saveQuestion(Question theQuestion) {
		// TODO Auto-generated method stub
		questionDAO.saveQuestion(theQuestion);
	}



	@Override
	public void updateQuestion(Question theQuestion) {
		
		// TODO Auto-generated method stub
		questionDAO.updateQuestion(theQuestion);
	}

	@Override
	public void deleteQuestion(int qno, String cname, int cd) {
		// TODO Auto-generated method stub
		questionDAO.deleteQuestion(qno,cname,cd);
	}

	@Override
	public List<Question> getQuestions(String cname, int iid) {
		// TODO Auto-generated method stub
		return questionDAO.getQuestions(cname,iid);
	}

	@Override
	public Question getQuestion(int qno, String cd, int iid) {
		// TODO Auto-generated method stub
		return questionDAO.getQuestion(qno,cd,iid);
	}



	@Override
	public int[] validateTestId(String testId) {
		// TODO Auto-generated method stub
		return questionDAO.validateTestId(testId);
	}



	@Override
	public List<Question> getStudQuestions(int i, int j) {
		// TODO Auto-generated method stub
		return questionDAO.getStudQuestions(i,j);
	}

}
