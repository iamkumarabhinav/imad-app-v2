package com.springdemo.validator;

import org.springframework.stereotype.Component;
import org.springframework.validation.Errors;
import org.springframework.validation.ValidationUtils;
import org.springframework.validation.Validator;

import com.springdemo.entity.User;

@Component
public class UserValidator implements Validator {

	@Override
	public boolean supports(Class<?> clazz) {
		return User.class.isAssignableFrom(clazz);
	}

	@Override
	public void validate(Object target, Errors errors) {
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "error.email", "email is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "error.userRole", "userRole is required");
		ValidationUtils.rejectIfEmpty(errors, "error.mobile", "mobile is required");
		ValidationUtils.rejectIfEmpty(errors, "error.roll", "roll is required");
		ValidationUtils.rejectIfEmptyOrWhitespace(errors, "error.studName", "studName is required");
		User user = (User) target;
		if(user.getPwd().length() <= 9)
		{
			errors.rejectValue("error.pwd","pwd is required");
		}
	}

}