package com.springdemo.util;

import java.sql.ResultSet;
import java.sql.SQLException;

import org.springframework.jdbc.core.RowMapper;
import com.springdemo.entity.Question;

public class QuestionRowMapper implements RowMapper<Question> {

	@Override
	public Question mapRow(ResultSet rs, int rowNum) throws SQLException {
		Question tempQuestion=new Question();
		tempQuestion.setCname(rs.getString(1));
		tempQuestion.setQuesno(rs.getInt(2));
		tempQuestion.setQues(rs.getString(3));
		tempQuestion.setOpt1(rs.getString(4));
		tempQuestion.setOpt2(rs.getString(5));
		tempQuestion.setOpt3(rs.getString(6));
		tempQuestion.setOpt4(rs.getString(7));
		tempQuestion.setAns(rs.getInt(8));
		tempQuestion.setMarks(rs.getInt(9));
		tempQuestion.setIid(rs.getInt(10));
		return tempQuestion;
	}

}
