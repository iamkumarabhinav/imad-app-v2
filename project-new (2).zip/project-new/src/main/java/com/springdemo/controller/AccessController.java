package com.springdemo.controller;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.springdemo.entity.User;
import com.springdemo.service.UserService;
import com.springdemo.validator.UserValidator;

@Controller
@RequestMapping("/login")
public class AccessController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private UserValidator userValidator;
	
	@GetMapping("/showFormForLogin")
	public String showFormForLogin(Model theModel){
		User theUser=new User();
		theModel.addAttribute("user",theUser);
		System.out.println("Control in login/showForm For Login");
		return "login-form";
	}
	
	@PostMapping("/verifyLogin")
	public String verifyLogin(@ModelAttribute("user") User theUser,ModelMap model,Model theModel,RedirectAttributes redirectAttributes,HttpSession session){
		int x=userService.verifyUser(theUser);
		if(x%10==1)
		{
			User aUser=userService.getUser(x/10);
			theModel.addAttribute("user",aUser);
			session.setAttribute("aUser",aUser);
			System.out.println("Control in /verifylogin directed to student home");
			return "redirect:/student/home";
		}
		else if(x%10==2)
		{
			User aUser=userService.getUser(x/10);
			redirectAttributes.addAttribute("uid",aUser.getRoll());
			redirectAttributes.addFlashAttribute("user",aUser);
			System.out.println("Control in /verifylogin directed to teacher home");
			return "redirect:/teacher/home";
		}
		else
		{
			String message="Invalid username and password";
			model.addAttribute("msg",message);
			System.out.println("Control in /verifylogin directed to login form invalid pwd");
			return "login-form";
		}
	}
	
	
	@GetMapping("/showFormForRegistration")
	public String showFormForRegistration(Model theModel){
		User theUser=new User();
		theModel.addAttribute("user",theUser);
		System.out.println("Control in /showFormForRegistration directed to registration form");
		return "registration-form";
	}
	
	
	@PostMapping("/addUser")
	public String addUser(@ModelAttribute("user") User theUser,ModelMap model,BindingResult result){
	/*	userValidator.validate(theUser, result);
		
		if (result.hasErrors()) {
	        return "registration-form";
	    }
		*/
		boolean x;
		String regex = "^(.+)@(.+)$";
		String regexStr = "^[0-9]{10}$";
		Pattern pattern = Pattern.compile(regex);
		Pattern pattern1 = Pattern.compile(regexStr);
		Matcher matcher = pattern.matcher(theUser.getEmail());
		Matcher matcher1 = pattern1.matcher(theUser.getMobile());
		if(matcher.matches())
		{
		
			if(matcher1.matches())
			{
				x=userService.addUser(theUser);
				if(x==true)
					return "redirect:/login/showFormForLogin";
				else
				{
					String message="Error! Please Enter a valid Email Id";
					model.addAttribute("msg",message);
					return "registration-form";
				}
			}
			else{
				String message="Error! Please Enter a valid Mobile Number";
				model.addAttribute("msg",message);
				return "registration-form";
			}
			
		}
		else{
			String message="Error! Incorrect Email Id";
			model.addAttribute("msg",message);
			return "registration-form";
		}
		
	}

}
