package com.springdemo.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.util.SystemPropertyUtils;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.springdemo.entity.Course;
import com.springdemo.entity.Question;
import com.springdemo.entity.User;
import com.springdemo.service.QuestionService;
import com.springdemo.service.UserService;

@Controller
@RequestMapping("/student")
public class StudentController {
	
	@Autowired
	private UserService userService;
	
	@Autowired
	private QuestionService questionService;
	
	@GetMapping("/home")
	public String showHome(@ModelAttribute("user") User aUser,Model aModel,ModelMap model,HttpSession session){
		String testId="";
		aModel.addAttribute("testId",testId);
		session.setAttribute("num",0);
		session.setAttribute("marks",0);
		session.setAttribute("answer",999);
		session.setAttribute("qmark", 0);
			return "student-home";		
	}
	
	@PostMapping("/validateTestId")
	public String validateTestId(@ModelAttribute("question") Question theQuestion,@RequestParam("testId") String testId,ModelMap model,Model aModel,HttpSession session)
	{
		String message="";
		model.addAttribute("testId",testId);
		int x[]=questionService.validateTestId(testId);
		int no=(int) session.getAttribute("num");
		int m=(int) session.getAttribute("marks");
		int a=(int) session.getAttribute("answer");
		int qm=(int) session.getAttribute("qmark");
		if(theQuestion.getAns()==a)
		{
			m=m+qm;
			System.out.println("marks="+m);
		}
		System.out.println(no);
		if(x[2]==1)
		{
			List<Question> theQuestions = questionService.getStudQuestions(x[0],x[1]);
			int i=0;
			for(Question ques :theQuestions)
			{
				if(no==theQuestions.size()){
					model.addAttribute("marks",m);
					return "see-marks";
				}
				if(i==no){
					aModel.addAttribute("question",ques);
					session.setAttribute("num",++no);
					session.setAttribute("answer",ques.getAns());
					session.setAttribute("marks",m);
					session.setAttribute("qmark",ques.getMarks());
					message="Submit";
					model.addAttribute("msg",message);
					return "question-ans";
				}
				i++;
				
			}
			return "question-ans";
		}
		else 
		{  
			message="Enter a valid TestId";
			model.addAttribute("msg",message);
			return "student-home";
		}
	}
	
	
}