package com.springdemo.controller;

import java.util.List;
import java.util.Random;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.springdemo.entity.Course;

import com.springdemo.entity.User;
import com.springdemo.service.CourseService;
import com.springdemo.service.UserService;

@Controller
@RequestMapping("/teacher")
public class TeacherController {
	
	
	@Autowired
	private CourseService courseService;
	
	@Autowired
	private UserService userService;
	
	
	@GetMapping("/home")
	public String showHome(Model aModel,ModelMap model,@RequestParam("uid") int uid){
		boolean x=courseService.checkNewTeacher(uid);
		List<Course> theCourses = courseService.getAllCourse(uid);
		List<Course> ableCourse = courseService.getAbleCourse(uid);
		System.out.println(uid);
		if(x==true)
		{
			String message="Please Select A course in which you want to conduct a Test";
			model.addAttribute("msg",message);
		}
		User aUser=userService.getUser(uid);
		String testId="";
		aModel.addAttribute("courses",theCourses);
		aModel.addAttribute("user",aUser);
		aModel.addAttribute("acourses",ableCourse);
		model.addAttribute("testId",testId);
			return "teacher-home";
	}
	
	
	/*
	 * @GetMapping("/home")
	public String showHome(@ModelAttribute("user") User aUser,Model aModel,ModelMap model,@RequestParam("uid") int uid){
		boolean x=courseService.checkNewTeacher(uid);
		List<Course> theCourses = courseService.getAllCourse(aUser.getRoll());
		List<Course> ableCourse = courseService.getAbleCourse(aUser.getRoll());
		System.out.println(uid);
		if(x==true)
		{
			String message="Please Select A course in which you want to conduct a Test";
			model.addAttribute("msg",message);
		}
		aUser=userService.getUser(uid);
		String testId="";
		aModel.addAttribute("courses",theCourses);
		aModel.addAttribute("user",aUser);
		aModel.addAttribute("acourses",ableCourse);
		model.addAttribute("testId",testId);
			return "teacher-home";
			
			
	}
	 */
	
	@GetMapping("/enrollTeacher")
	public String enrollTeacher(@RequestParam("cid") int cid, @RequestParam("iid") int iid ,RedirectAttributes redirectAttributes,Model aModel)
	{
		User aUser=userService.getUser(iid);
		courseService.enrollTeacher(cid,iid);
		redirectAttributes.addFlashAttribute("user",aUser);
		String testId="";
		aModel.addAttribute("testId",testId);
		redirectAttributes.addAttribute("uid",iid);
		return "redirect:/teacher/home";
	}
	
	@GetMapping("/generateTestId")
	public String generateTestId(@RequestParam("cname") String cname, @RequestParam("iid") int iid ,ModelMap model)
	{
		String testId="";
	    int x=iid*7+3;
		String y=String.format("%05d", x);
		testId=testId+cname.toUpperCase()+y;
		model.addAttribute("testId",testId);
		model.addAttribute("uid",iid);
		courseService.generateTestId(cname,iid,testId);
		return "testId";
	}
	

}
