package com.springdemo.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.springdemo.entity.Question;
import com.springdemo.service.QuestionService;

@Controller
@RequestMapping("/question")
public class QuestionController {
	
	@Autowired
	private QuestionService questionService;
	
	@GetMapping("/list")
	public String listQuestions(Model theModel,@RequestParam("cname") String cname, @RequestParam("iid") int iid,ModelMap model,ModelMap model1 ){
		List<Question> theQuestions = questionService.getQuestions(cname,iid);
		theModel.addAttribute("questions",theQuestions);
		model.addAttribute("cname", cname);
		model1.addAttribute("iid", iid);
		return "question-page";
	}
	
	@GetMapping("/showFormForAdd")
	public String showFormForAdd(Model theModel,@RequestParam("cname") String cname, @RequestParam("iid") int iid,ModelMap model){
		Question theQuestions=new Question();
		theModel.addAttribute("question",theQuestions);
		model.addAttribute("cname", cname);
		model.addAttribute("iid", iid);
		String message="Save Question";
		model.addAttribute("msg",message);
		return "question-form";
	}
	
	@PostMapping("/saveQuestion")
	public String saveQuestion(@ModelAttribute("question") Question theQuestion,@RequestParam("msg") String msg,ModelMap model){
		if(msg.equals("Save Question"))
			questionService.saveQuestion(theQuestion);
		else if(msg.equals("Edit Question"))
			questionService.updateQuestion(theQuestion);
		System.out.println(theQuestion);
		model.addAttribute("cname", theQuestion.getCname());
		model.addAttribute("iid",theQuestion.getIid());
		return "redirect:/question/list";
	}
	
	@GetMapping("/showFormForUpdate")
	public String showFormForUpdate(@RequestParam("quesno") int qno, @RequestParam("cname") String cname,@RequestParam("iid") int iid ,Model theModel,ModelMap model){
		Question theQuestion = questionService.getQuestion(qno,cname,iid);
		theModel.addAttribute("question",theQuestion);
		model.addAttribute("cname", cname);
		model.addAttribute("iid", iid);
		String message="Edit Question";
		model.addAttribute("msg",message);
		return "question-form";
	}
	
	@GetMapping("/delete")
	public String deleteQuestion(@RequestParam("quesno") int qno, @RequestParam("cname") String cname,@RequestParam("iid") int iid  ,Model theModel,ModelMap model){
		questionService.deleteQuestion(qno,cname,iid);
		model.addAttribute("cname", cname);
		model.addAttribute("iid", iid);
		return "redirect:/question/list";
	}
	
}
