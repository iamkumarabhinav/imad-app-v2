package com.springdemo.entity;

public class User {
	
	private int roll;
	private String studName;
	private String pwd;
	private String userRole;
	private String email; 
	private String mobile;
	public User() {
		super();
	}
	@Override
	public String toString() {
		return "User [roll=" + roll + ", studName=" + studName + ", pwd=" + pwd + ", userRole=" + userRole + ", email="
				+ email + ", mobile=" + mobile + "]";
	}
	public User(int roll, String studName, String pwd, String userRole, String email, String mobile) {
		super();
		this.roll = roll;
		this.studName = studName;
		this.pwd = pwd;
		this.userRole = userRole;
		this.email = email;
		this.mobile = mobile;
	}
	public int getRoll() {
		return roll;
	}
	public void setRoll(int roll) {
		this.roll = roll;
	}
	public String getStudName() {
		return studName;
	}
	public void setStudName(String studName) {
		this.studName = studName;
	}
	public String getPwd() {
		return pwd;
	}
	public void setPwd(String pwd) {
		this.pwd = pwd;
	}
	public String getUserRole() {
		return userRole;
	}
	public void setUserRole(String userRole) {
		this.userRole = userRole;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	

}
